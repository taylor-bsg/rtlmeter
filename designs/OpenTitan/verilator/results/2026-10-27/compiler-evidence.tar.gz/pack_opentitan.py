"""Stage exact new model code, runtime, immutable inputs and output references."""
import hashlib
import json
from pathlib import Path
import shutil
import tarfile
from build import ROOT, WORK, SRC, save
from opentitan_models import LABELS

dest=ROOT/'payload'
dest.mkdir(exist_ok=False)

def copy(source,target):
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(source,target)

record=json.loads((ROOT/'opentitan-input.json').read_text())
for name,sha in record['source_sha256'].items():
    assert hashlib.sha256((WORK/'rtlmeter-unit-profiles'/name).read_bytes()).hexdigest()==sha,name
assert json.loads((ROOT/'opentitan-assignment-audit.json').read_text())['passed']
for label in LABELS:
    model=ROOT/'models'/label
    assert json.loads((model/'generation.json').read_text())['returncode']==0
    for p in (model/'obj_dir').iterdir():
        if p.suffix in ('.cpp','.h','.mk','.txt'):
            copy(p,dest/'models'/label/p.name)
    for part in record['compile']:
        assert not part.get('cppIncludeFiles')
        for name in part.get('cppSourceFiles',[]):
            copy(WORK/'rtlmeter-unit-profiles/designs/OpenTitan'/name,dest/'models'/label/'cppSourceFiles'/Path(name).name)
    for name in ('generation.json','command.json'):
        copy(model/name,dest/'provenance'/label/name)
for p in (SRC/'include').rglob('*'):
    if p.is_file() and p.suffix not in ('.o','.d','.a','.gch','.pch','.pyc','.md'):
        copy(p,dest/'runtime/include'/p.relative_to(SRC/'include'))
for name in ('verilator_includer','verilator_ccache_report'):
    copy(SRC/'bin'/name,dest/'runtime/bin'/name)
for name in ('worker.py','affinity.c'):
    copy(WORK/'bit-copy-suite'/name,dest/name)
for test in ('aes','cmark','rsa','sha'):
    case='OpenTitan-default-'+test
    old=WORK/'package60-review/payloads/native/workloads'/case
    shutil.copytree(old,dest/'workloads'/case)
    copy(WORK/'package60-review/remote-evidence/results/references'/(case+'.json'),dest/'results/references'/(case+'.json'))
for name in ('run_opentitan.py','source-provenance.json','opentitan-input.json','opentitan-assignment-audit.json','focused.json','binaries.json'):
    copy(ROOT/name,dest/name)
shutil.copytree(ROOT/'profiles',dest/'profiles')
save(dest/'payload-manifest.json',{str(p.relative_to(dest)):hashlib.sha256(p.read_bytes()).hexdigest()
                                 for p in dest.rglob('*') if p.is_file()})
with tarfile.open(ROOT/'opentitan-payload.tar.gz','w:gz',compresslevel=3) as tar:
    for p in sorted(dest.iterdir()):tar.add(p,arcname=p.name)
print('Payload bytes:',(ROOT/'opentitan-payload.tar.gz').stat().st_size)

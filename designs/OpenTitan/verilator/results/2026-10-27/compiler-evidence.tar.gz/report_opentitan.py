"""Independently audit the completed native evidence and publish measured results."""
import csv
import hashlib
import io
import json
from pathlib import Path
import shutil
import statistics
import tarfile
from build import ROOT, WORK, save
from opentitan_models import LABELS

def read(path):return json.loads(path.read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

evidence=ROOT/'remote-evidence'
assert not (evidence/'results/STOP.json').exists()
assert read(evidence/'results/DONE.json')==dict(passed=True,checks=16,timings=48)
for name,expected in read(evidence/'evidence-manifest.json').items():
    assert sha(evidence/name)==expected,name
assert read(evidence/'payload-manifest.json')==read(ROOT/'payload/payload-manifest.json')
for name,expected in read(ROOT/'payload/payload-manifest.json').items():
    assert sha(ROOT/'payload'/name)==expected,name
assert read(ROOT/'opentitan-workload-audit.json')['passed']
assert read(ROOT/'opentitan-assignment-audit.json')['passed']

cases=['OpenTitan-default-'+test for test in ('aes','cmark','rsa','sha')]
builds={label:read(evidence/'results/builds'/label/'summary.json') for label in LABELS}
for label,row in builds.items():
    assert row['passed']
    command=read(evidence/'results/builds'/label/'command.json')
    for expected in ['CC=/usr/bin/clang-21','CXX=/usr/bin/clang++-21','LINK=/usr/bin/clang++-21','CXXFLAGS=-std=gnu++20']:
        assert expected in command
    lines=(evidence/'results/builds'/label/'build.log').read_text().splitlines()
    commands=[line for line in lines if ' -c ' in line or ' -o Vsim' in line]
    assert len(commands)==row['clang_commands']
    assert all(line.startswith('/usr/bin/clang++-21 ') for line in commands)
rows=[];executions=[];inodes=set();summary=[]
for case in cases:
    reference=read(evidence/'results/references'/(case+'.json'))
    for label in LABELS:
        workers=int(label.rsplit('-',1)[1])
        times=[]
        for phase,repetitions in [('check',[0]),('timing',[1,2,3])]:
            for rep in repetitions:
                dest=evidence/'results'/phase/case/label/f'round-{rep}'
                row=read(dest/'summary.json');placement=read(dest/'placement.json')
                assert row['passed'] and placement['passed']
                assert (row['case'],row['label'],row['phase'],row['repetition'])==(case,label,phase,rep)
                assert row['binary_sha256']==builds[label]['binary_sha256']
                assert row['output_sha256']==sha(dest/'_execute/stdout.log')==reference['output_sha256']
                assert row['clocks']==int((dest/'_rtlmeter_cycles.txt').read_text())==reference['clocks']
                if 'check_sha256' in reference:assert sha(dest/'check.bin')==reference['check_sha256']
                assert row['cpus']==list(range(workers)) and row['memory_node']==0
                events=[json.loads(line) for line in (dest/'affinity.jsonl').read_text().splitlines()]
                assert events[-1]['event']=='end' and events[-1]['workers']==workers
                assert [e['cpu'] for e in events if e['event']=='thread_created']==list(range(1,workers))
                assert row['seconds']==events[-1]['elapsed']>0
                assert placement['samples'] and set(placement['executable_pages']['counts'])=={'0'}
                for sample in placement['samples']:
                    assert sorted(sample['affinities'].values())==[[i] for i in range(workers)]
                copied=read(dest/'binary-copy.json')
                assert copied['binary_sha256']==row['binary_sha256'] and copied['copy_cpu']==0
                assert copied['inode'] not in inodes;inodes.add(copied['inode'])
                executions.append(row)
                if phase=='timing':times.append(row['seconds']);rows.append(row)
        summary.append(dict(case=case,label=label,workers=workers,median_seconds=statistics.median(times),
                            minimum_seconds=min(times),maximum_seconds=max(times),samples_seconds=times,
                            clocks=reference['clocks']))
assert len(rows)==48 and len(executions)==64
assert sorted(rows,key=lambda r:(r['case'],r['label'],r['repetition']))==sorted(
    read(evidence/'results/timings.json'),key=lambda r:(r['case'],r['label'],r['repetition']))
for case in cases:
    serial=next(row['median_seconds'] for row in summary if row['case']==case and row['workers']==1)
    for row in summary:
        if row['case']==case:row['speedup_vs_one_worker']=serial/row['median_seconds']
save(ROOT/'opentitan-native-audit.json',dict(passed=True,correctness_checks=16,timings=48,
    independent_raw_log_and_hash_audit=True,unique_executable_inodes=len(inodes),
    live_single_cpu_affinity_all_runs=True,executable_pages_node_zero_all_runs=True,clang_only_builds=True))
save(ROOT/'opentitan-summary.json',dict(passed=True,configurations=summary))

repo=WORK/'rtlmeter-unit-profiles'
target=repo/'designs/OpenTitan/verilator/results/2026-10-27'
target.mkdir(parents=True,exist_ok=True)
for name in ['opentitan-native-audit.json','opentitan-workload-audit.json','opentitan-assignment-audit.json',
             'source-provenance.json','binaries.json','focused.json','opentitan-summary.json']:
    shutil.copy2(ROOT/name,target/name)
shutil.copy2(ROOT/'evidence.tar.gz',target/'native-evidence.tar.gz')
shutil.copy2(ROOT/'profiles/original-auto.vlt',target/'original-auto.vlt')
shutil.copy2(ROOT/'models/OpenTitan-default-mapped-8/obj_dir/Vsim__threads_units.txt',target/'threads-unit-indices.txt')
with (target/'timings.csv').open('w',newline='') as stream:
    fields=['case','label','workers','repetition','seconds','clocks','output_sha256','binary_sha256']
    writer=csv.DictWriter(stream,fieldnames=fields,extrasaction='ignore',lineterminator='\n')
    writer.writeheader();writer.writerows(rows)
local_files=[]
for name in ['build.py','opentitan_models.py','audit_opentitan.py','audit_inputs.py','pack_opentitan.py',
             'report_opentitan.py','dispatch-audit-body.py','opentitan-input.json','opentitan-generation.json']:
    local_files.append(ROOT/name)
for name in ('build','configure','autoconf','focus-release','focus-debug'):
    if (ROOT/'checks'/name).exists():local_files.extend(p for p in (ROOT/'checks'/name).rglob('*') if p.is_file())
with tarfile.open(target/'compiler-evidence.tar.gz','w:gz',compresslevel=6) as tar:
    manifest={}
    for path in sorted(local_files):
        name=str(path.relative_to(ROOT));manifest[name]=sha(path);tar.add(path,arcname=name)
    data=(json.dumps(manifest,indent=2)+'\n').encode();member=tarfile.TarInfo('manifest.json');member.size=len(data)
    tar.addfile(member,io.BytesIO(data))

by={(row['case'],row['label']):row for row in summary}
headers=['Workload','1 worker (s)','Earlier auto, 25 units (s)','Auto, 54 units (s)','Mapped 8 workers (s)','Speedup vs. 1 worker']
table='| '+' | '.join(headers)+' |\n|---|---:|---:|---:|---:|---:|\n'
details='| Workload | Runtime reduction vs. earlier auto | Runtime reduction vs. same-unit auto | Mapped range (s) | Cycles |\n|---|---:|---:|---:|---:|\n'
rstrows=[]
for case in cases:
    values=[by[case,label] for label in LABELS]
    test=case.removeprefix('OpenTitan-default-')
    columns=[test]+[f'{row["median_seconds"]:.3f}' for row in values]+[f'{values[-1]["speedup_vs_one_worker"]:.2f}x']
    table+='| '+' | '.join(columns)+' |\n';rstrows.append(columns)
    original,auto,mapped=[row['median_seconds'] for row in values[1:]]
    details+=f'| {test} | {(1-mapped/original)*100:.1f}% | {(1-mapped/auto)*100:.1f}% | {values[-1]["minimum_seconds"]:.3f}–{values[-1]["maximum_seconds"]:.3f} | {values[-1]["clocks"]:,} |\n'
text=f'''# OpenTitan default: saved placement with the final loop optimization

The saved 54-unit kk10 placement improves all four measured performance workloads.
The portable profile now selects the same 54 units with automatic assignment.
All configurations below use the same final compiler integration, so this
comparison measures grouping/placement, not the isolated effect of the loop optimization.

{table}
Times are medians of three isolated runs per configuration/workload, measured
with the native process preload timer on kk10 on 2026-10-27, including model
initialization, simulation, and cleanup. The earlier automatic
control uses the [previous 25-unit grouping](original-auto.vlt). The other
automatic control has exactly the same unit inventory as the mapped profile.
The one-worker model is a separate serial build without grouping directives.

{details}
## Source and execution setup

- RTLMeter inputs: `39a9a85c5b32da0ec8b0184fd57c9a9fb2b919ee`, unmodified RTL and firmware.
- Verilator: [`2487df5b4b8665f0caf8aed7ea174d13c037bf19`](https://github.com/taylor-bsg/verilator/tree/2487df5b4b8665f0caf8aed7ea174d13c037bf19),
  branch `codex/threads-unit-runtime-integration`.
- That branch combines worker assignment `8c052270`, final wide-zero-reset
  commit `546644f5` (PR #8916), and final bit-copy commit `ddbd470c` (PR #8933).
  The only extra adaptation removes two warning-control comments unsupported by
  the older base from a test. Scheduler, cost, and merging heuristics are unchanged.
- Both Verilator and every fresh model use Clang 21.1.8. Model compile/link drivers
  are explicitly `/usr/bin/clang++-21`; default hot-code optimization is `-Os`,
  with C++20. No PGO, LTO, or custom unrolling flags are added.
- Logical worker `i` is pinned to physical CPU `i`. CPUs 0–3 and 4–7 are two
  chiplets on socket 0. The caller/scheduler is worker 0. The serial reference
  also uses CPU 0. All runs bind memory to node 0.
- AES/RSA/SHA use their descriptor's three workload iterations; CoreMark uses
  one. Each timed process starts afresh. The `hello` sanity workload is not part
  of this four-workload timing matrix.
- Every run uses its own copied executable inode; live checks verify singleton
  per-thread CPU affinity and resident executable pages on node 0.
- A shared benchmark lock covers all builds and executions. All builds finish
  before correctness screens. All 16 screens finish before any timed run.
  Round 2 reverses case/configuration order; there are 48 timed runs total.

## Correctness and assignment verification

All **16 correctness screens and 48 timed runs passed** the original post-hook,
matched the immutable reference stdout byte for byte, and had identical cycle
counts for each workload. Reference outputs came from the already validated
package-60 runs; this comparison does not regenerate expected output from the candidate.
The descriptor, HDL/C++, firmware, and hook hashes match the pinned source.

All **54 selected units** and their emitted descendant calls were audited through
the generated worker dispatch. Child units override an enclosing unit; other
logic stays with its nearest selected ancestor. The mapped NBA graph has
237 tasks and 748 edges. All four builds perform 151 bit-copy lowerings.
The integration compiler also passed 23 focused tests in release and 23 in debug.

The original AES placement search selected this map. This follow-up validates
the saved map with the final compiler changes and the original synchronization
and merging heuristics. Performance on other hardware and worker counts remains
unmeasured.

## Reproduction and evidence

Use the [portable profile](../../threads-unit.vlt) or the self-contained
[kk10 profile](../../threads-unit-kk10.vlt), one at a time. See the
[collection documentation](../../../../../docs/source/threads-unit.rst) for selection syntax.
After normal RTLMeter setup and building the pinned Verilator with
`CC=/usr/bin/clang-21 CXX=/usr/bin/clang++-21`, a compile/listing example from
the RTLMeter root is:

```sh
profile="$PWD/designs/OpenTitan/verilator/threads-unit-kk10.vlt"
MAKEFLAGS='CXX=/usr/bin/clang++-21 LINK=/usr/bin/clang++-21 CXXFLAGS=-std=gnu++20 OBJCACHE=' \\
  ./rtlmeter run --cases 'OpenTitan:default:aes' \\
  --compileArgs="--threads 8 --compiler clang --threads-unit-list '$profile'" \\
  --nExecute 0 --workRoot work-opentitan-kk10
```

The VLT does not set affinity. For timing, use the recorded launcher and preload
shim in the native evidence with `HB_CPUS=0,1,2,3,4,5,6,7` and
`VERILATOR_NUMA_STRATEGY=none`. A process-wide CPU mask alone does not reproduce
the per-thread placement. The original launcher's paths are recorded verbatim
and must be relocated when reproducing on another checkout.

- [Raw timings](timings.csv) and [medians/ranges](opentitan-summary.json).
- [Generated module-index-to-worker listing](threads-unit-indices.txt).
- [Assignment audit](opentitan-assignment-audit.json), [workload/source audit](opentitan-workload-audit.json),
  and [independent native audit](opentitan-native-audit.json).
- [Compiler/source provenance](source-provenance.json) and [compiler binary hashes](binaries.json).
- [Native evidence](native-evidence.tar.gz): all build commands/logs, correctness and
  timing stdout, hooks, cycle files, affinity records, placement samples,
  binary hashes, reference outputs, controller, worker, and machine topology.
- [Compiler evidence](compiler-evidence.tar.gz): integration build/test logs,
  model-generation commands/hashes, and audit scripts. Test harness logs named
  `vlt_gcc.log` contain the actual Clang invocations; the filename is historical.
- Both archives contain SHA-256 manifests; [manifest.json](manifest.json) hashes
  every published result file. Generated binaries are not committed.
'''
(target/'RESULTS.md').write_text(text)
save(target/'manifest.json',{p.name:sha(p) for p in sorted(target.iterdir()) if p.is_file() and p.name!='manifest.json'})

docs=repo/'docs/source/threads-unit.rst'
content=docs.read_text()
assert '\nOpenTitan on kk10\n' not in content
section='''OpenTitan on kk10
------------------

``designs/OpenTitan/verilator/threads-unit.vlt`` selects 54 module instances with
automatic placement. ``threads-unit-kk10.vlt`` selects the same units with the
saved AES runtime-guided placement for eight workers. Worker ``i`` is pinned
to CPU ``i``; workers 0–3 and 4–7 occupy two chiplets on socket 0. The caller
and scheduler are worker 0. The profile does not set physical affinity.

These results use the separate `compiler integration branch
<https://github.com/taylor-bsg/verilator/tree/2487df5b4b8665f0caf8aed7ea174d13c037bf19>`_
at ``2487df5b4b8665f0caf8aed7ea174d13c037bf19``. It adds the final wide-zero-reset
and bit-copy optimizations to the worker-assignment baseline. It preserves
the original scheduler, cost, and merging heuristics. Earlier designs' results
above retain their recorded compiler revisions.

All four fresh models use Clang 21.1.8 and default Verilator C++ optimization
flags. The RTL/firmware input revision is
``39a9a85c5b32da0ec8b0184fd57c9a9fb2b919ee``. Measurements ran on kk10 on
2026-10-27, with memory bound to node 0 and the one-worker reference on CPU 0.
AES, RSA, and SHA retain three workload iterations; CoreMark retains one.
Times are medians of three interleaved, isolated process runs, including
initialization and cleanup. All configurations include the compiler fixes.

.. list-table:: OpenTitan default placement comparison
   :header-rows: 1

'''
for columns in [headers]+rstrows:
    section+='   * - '+columns[0]+'\n'+''.join('     - '+v+'\n' for v in columns[1:])
section+='''
All 16 correctness screens and 48 timed runs passed the original post-hook,
matched immutable previously validated stdout, and had the reference cycle
count. All 54 unit assignments and descendant dispatch owners were audited.
Live checks verified individual CPU pinning and executable-page locality for
every run. The separate ``hello`` sanity workload remains outside this matrix.

The `complete results and reproduction evidence
<https://github.com/taylor-bsg/rtlmeter/blob/codex/threads-unit-profiles/designs/OpenTitan/verilator/results/2026-10-27/RESULTS.md>`_
include ranges, raw timings, source hashes, build/test logs, and the generated
module-index-to-worker listing. Only the default design with eight workers is
explicitly mapped. Load one profile at a time.

Caliptra and NVDLA preparation
------------------------------

The requested 0.25% hierarchy inventories are now available for
`Caliptra
<https://github.com/taylor-bsg/rtlmeter/blob/codex/threads-unit-profiles/designs/Caliptra/verilator/analysis/README.md>`_
and `NVDLA
<https://github.com/taylor-bsg/rtlmeter/blob/codex/threads-unit-profiles/designs/NVDLA/verilator/analysis/README.md>`_.
They contain 174 and 128 qualifying instances respectively, topology diagrams,
candidate unit boundaries, structural connection lists, and interactive
hierarchies to download. Percentages are static compiler work estimates, not
runtime samples; connectivity counts are not bandwidth measurements.
Unit selection, worker assignment, and placement benchmarking remain pending.

'''
content=content.replace('Coverage and validation\n',section+'Coverage and validation\n',1)
anchor='.. list-table:: Designs still needing profiles and validation\n'
entries='''   * - OpenTitan
     - ``threads-unit.vlt``
     - Same 54 units as the machine profile, automatic assignment. All four
       performance workloads passed the fresh LLVM comparison above.
   * - OpenTitan
     - ``threads-unit-kk10.vlt``
     - Saved eight-worker mapping, all 54 unit/descendant dispatch owners
       audited. AES, CoreMark, RSA, and SHA passed all correctness checks;
       medians and speedups are in the table above.

'''
content=content.replace(anchor,entries+anchor,1)
content=content.replace('   * - Caliptra\n     - Pending\n','   * - Caliptra\n     - Hierarchy/connectivity analysis complete; unit selection and placement pending.\n')
content=content.replace('   * - NVDLA\n     - Pending\n','   * - NVDLA\n     - Hierarchy/connectivity analysis complete; unit selection and placement pending.\n')
content=content.replace('   * - OpenTitan\n     - Pending\n','')
docs.write_text(content)
print(table)
print(details)
print('PASS: 64 native executions audited; profiles/results/docs staged')

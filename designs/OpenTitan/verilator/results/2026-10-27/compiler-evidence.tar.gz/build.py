"""Build and qualify the immutable worker-assignment/runtime integration."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
WORK = ROOT.parent
SRC = ROOT / 'compiler'
VENV = WORK / 'threads-unit-assignment-validation/venv/bin'
BASE = '8c052270d87fe6edef528d1f23b176b52682b212'
RESET = '6f67cfd409c70e193d4b801e771eb7cc336c0393'
LOOP = '3c02d04cd39b33722b56a17c5880edecbc050fd9'

def save(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2) + '\n')

def env():
    result = dict(os.environ)
    for name in ('VERILATOR_ROOT', 'VERILATOR_BIN', 'MAKEFLAGS', 'CFLAGS', 'CXXFLAGS', 'CPPFLAGS',
                 'LDFLAGS', 'LD_PRELOAD', 'OBJCACHE'):
        result.pop(name, None)
    result.update(CC='/usr/bin/clang-21', CXX='/usr/bin/clang++-21', LINK='/usr/bin/clang++-21',
                  VERILATOR_ROOT=str(SRC), CCACHE_DISABLE='1',
                  VERILATOR_SOLVER=str(WORK/'package60-review/tools/python/bin/z3') + ' --in',
                  PATH=':'.join(map(str, [WORK/'package60-review/tools/wavetools-v0.1.3-linux-x86_64',
                                        VENV, WORK/'package60-review/tools/python/bin'])) + ':' + result['PATH'])
    return result

def run(name, command, cwd=SRC, environment=None):
    dest=ROOT/'checks'/name
    dest.mkdir(parents=True,exist_ok=True)
    environment=environment or env()
    record=dict(command=command,cwd=str(cwd),environment={k:environment[k] for k in
                ('CC','CXX','LINK','VERILATOR_ROOT','VERILATOR_BIN','VERILATOR_SOLVER') if k in environment})
    save(dest/'command.json',record)
    print('START',name,flush=True)
    start=time.monotonic()
    with (dest/'output.log').open('w') as output:
        result=subprocess.run(command,cwd=cwd,env=environment,stdout=output,stderr=subprocess.STDOUT)
    record.update(returncode=result.returncode,seconds=time.monotonic()-start)
    save(dest/'result.json',record)
    print('DONE',name,result.returncode,flush=True)
    assert result.returncode==0,dest
    return record

def git(*args):
    return subprocess.check_output(['git',*args],cwd=SRC,text=True).strip()

def provenance():
    assert not git('status','--porcelain')
    assert git('rev-parse',LOOP+'~2')==BASE
    for filename in ('src/V3OrderParallel.cpp','src/V3OrderMTaskGraph.cpp','src/V3PackThreads.cpp'):
        assert git('diff',BASE,'HEAD','--',filename)==''
    assert git('show','HEAD:src/V3Unroll.cpp')==git('show','ddbd470c73ca9e5aa585aa1bbc8f48a35fa79492:src/V3Unroll.cpp')
    patches={}
    for original,local in [('546644f5ba1a908c8a4027d058c0dd4608e96753',RESET),
                           ('ddbd470c73ca9e5aa585aa1bbc8f48a35fa79492',LOOP)]:
        edits=[]
        for revision in (original,local):
            patch=git('show','--format=','--binary','--unified=0',revision)
            edits.append('\n'.join(line for line in patch.splitlines() if
                line.startswith(('diff --git ','old mode ','new mode ','new file mode ','deleted file mode '))
                or (line[:1] in ('+','-') and line[1:].strip() and not line.startswith(('+++','---')))))
        assert edits[0]==edits[1],original
        patches[original]=dict(local=git('rev-parse',local),nonblank_edit_sha256=hashlib.sha256(edits[0].encode()).hexdigest())
    save(ROOT/'source-provenance.json',dict(base=BASE,head=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),
         branch=git('branch','--show-current'),patches=patches,unchanged_scheduler=True,compiler_build_commit=LOOP,
         test_compatibility='Remove two UNOPTPUBLIC lint-control comments: this older base predates that warning. Public-destination behavior and checks are unchanged.',
         conflict_resolution='Only deletion context near absent VL_UNPACKED_FILL differed; retained the old runtime and removed VL_ZERO_RESET_W. All nonblank added/deleted lines and file modes match upstream exactly.',
         compiler=subprocess.check_output(['/usr/bin/clang++-21','--version'],text=True),
         rtlmeter_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK/'rtlmeter-unit-profiles',text=True).strip()))

def build():
    provenance()
    assert 'clang version 21.1.8' in subprocess.check_output(['/usr/bin/clang++-21','--version'],text=True)
    run('autoconf',['autoconf'])
    run('configure',['./configure','--enable-ccwarn','--enable-longtests','CC=/usr/bin/clang-21','CXX=/usr/bin/clang++-21'])
    run('build',['make','-j48','OBJCACHE='])
    save(ROOT/'binaries.json',{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (SRC/'bin').glob('*_bin*') if p.is_file()})

def focus():
    tests=sorted({str(p.relative_to(SRC/'test_regress')) for pattern in
        ('t_threads_unit*.py','t_unroll_bit_copy*.py','t_*bit_scan*.py','t_func_automatic_clear.py','t_var_reset*.py')
        for p in (SRC/'test_regress/t').glob(pattern)})
    rows=[]
    for label,binary in [('release','verilator_bin'),('debug','verilator_bin_dbg')]:
        environment=env();environment['VERILATOR_BIN']=str(SRC/'bin'/binary)
        rows.append(run('focus-'+label,[str(VENV/'python3'),'driver.py','--vlt','--vltmt','-j16',*tests],SRC/'test_regress',environment))
        for scenario in ('vlt','vltmt'):
            for test in tests:
                directory=SRC/'test_regress'/('obj_'+scenario)/Path(test).stem
                if not directory.exists():continue
                for path in directory.iterdir():
                    if path.is_file() and (path.suffix=='.log' or path.name.endswith('__stats.txt')):
                        target=ROOT/'checks'/('focus-'+label)/'artifacts'/scenario/directory.name/path.name
                        target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,target)
    save(ROOT/'focused.json',dict(passed=True,tests=tests,runs=rows))

if __name__=='__main__':
    for action in sys.argv[1:] or ['build','focus']:
        globals()[action]()

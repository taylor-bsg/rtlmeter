"""Check every staged OpenTitan workload against the pinned RTLMeter descriptor."""
import hashlib
import json
from pathlib import Path
from build import ROOT, WORK, save

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

record=json.loads((ROOT/'opentitan-input.json').read_text())
repo=WORK/'rtlmeter-unit-profiles'
design=repo/'designs/OpenTitan'
assert sha(design/'descriptor.yaml')==record['descriptor_sha256']
for name,expected in record['source_sha256'].items():
    assert sha(repo/name)==expected,name
execution=record['execute'][0]
assert record['execute'][1] is None
rows=[]
for test in ('aes','cmark','rsa','sha'):
    label='OpenTitan-default-'+test
    dest=ROOT/'payload/workloads'/label
    case=json.loads((dest/'case.json').read_text())
    config=execution['tests'][test]
    common=execution['common']
    assert case['args']==common.get('args',[])+config.get('args',[])
    files=common.get('files',[])+config.get('files',[])
    assert case['files']==[Path(name).name for name in files]
    assert case['post']==Path(common['postHook']).name
    sources=files+[common['postHook']]
    hashes={}
    for name in sources:
        expected=sha(design/name)
        assert sha(dest/Path(name).name)==expected,name
        hashes[name]=expected
    rows.append(dict(case=case['case'],args=case['args'],source_sha256=hashes,passed=True))
save(ROOT/'opentitan-workload-audit.json',dict(passed=True,cases=rows,
     descriptor_sha256=record['descriptor_sha256'],hdl_cpp_source_files=len(record['source_sha256'])))
print('PASS: descriptor, HDL/C++, and all four workload payloads match the pinned source')

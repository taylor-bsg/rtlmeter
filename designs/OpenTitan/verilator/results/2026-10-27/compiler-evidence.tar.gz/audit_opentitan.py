"""Verify the saved unit indices and every generated mapped-worker dispatch."""
import collections
import csv
import hashlib
import json
from pathlib import Path
import re
import shlex
from build import ROOT, WORK, save
from opentitan_models import LABELS

def listing(path):
    return [shlex.split(line) for line in path.read_text().splitlines()
            if line.strip() and not line.startswith('#')]

old=WORK/'opentitan-default-work/bit-copy-placement/models/bc06-kmac6-flash3/obj_dir/Vsim__threads_units.txt'
expected={s:(m,int(i),int(w)) for m,i,w,s,pattern in listing(old)}
obj=ROOT/'models/OpenTitan-default-mapped-8/obj_dir'
actual={s:(m,int(i),int(w)) for m,i,w,s,pattern in listing(obj/'Vsim__threads_units.txt')}
assert actual==expected and len(actual)==54
auto=listing(ROOT/'models/OpenTitan-default-auto-all-8/obj_dir/Vsim__threads_units.txt')
assert all(w=='auto' for m,i,w,s,p in auto)
assert {(m,int(i),s,p) for m,i,w,s,p in auto}=={(m,int(i),s,p) for m,i,w,s,p in listing(old)}
expected['chip_sim_tb']=('chip_sim_tb',0,0)
body=(WORK/'opentitan-default-work/bit-copy-placement/dispatch-audit-body.py').read_text()
(ROOT/'dispatch-audit-body.py').write_text(body)
namespace=dict(collections=collections,csv=csv,re=re,WORK=WORK/'opentitan-default-work',OBJ=obj,expected=expected)
exec(compile(body,str(ROOT/'dispatch-audit-body.py'),'exec'),namespace)
graphs={}
for label in LABELS:
    objdir=ROOT/'models'/label/'obj_dir'
    stats=(objdir/'Vsim__stats.txt').read_text()
    graph={}
    if not label.endswith('-1'):
        for key in ('mtask count','edge count','total graph cost','critical path cost'):
            graph[key]=int(re.search(r'MTask graph, final, '+key+r'\s+(\d+)',stats)[1])
        graph['selected_instances']=len(listing(objdir/'Vsim__threads_units.txt'))
    graph['lowered_bit_copy_loops']=int(re.search(r'Lowered bit-copy to part-select\s+(\d+)',stats)[1])
    graphs[label]=graph
save(ROOT/'opentitan-assignment-audit.json',dict(passed=True,units=len(actual),tasks=len(namespace['tasks']),
    all_indices_and_workers_match_saved_mapping=True,all_emitted_unit_dispatch_owners_match=True,
    same_unit_auto_control_matches_inventory=True,logical_worker_to_cpu=list(range(8)),scheduler_worker=0,
    listing_sha256=hashlib.sha256((obj/'Vsim__threads_units.txt').read_bytes()).hexdigest(),
    owners={scope:sorted(workers) for scope,workers in namespace['owners'].items()},
    schedules=namespace['schedules'],graphs=graphs,
    scope='Retained units and descendant-interface calls in parallel NBA dispatch; serial ACT executes on caller'))
print(json.dumps(dict(passed=True,units=len(actual),graphs=graphs),indent=2))

"""Generate four fresh OpenTitan controls with identical compiler/RTL inputs."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time
from build import ROOT, WORK, SRC, env, save

LABELS=('OpenTitan-default-serial-1','OpenTitan-default-original-auto-8',
        'OpenTitan-default-auto-all-8','OpenTitan-default-mapped-8')

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def prepare():
    manifest=json.loads((WORK/'bit-copy-suite/manifest.json').read_text())
    record=next(r for r in manifest['cases'] if r['design']=='OpenTitan')
    for name,expected in record['source_sha256'].items():
        assert digest(WORK/'rtlmeter-unit-profiles'/name)==expected,name
    save(ROOT/'opentitan-input.json',record)
    mapped=(WORK/'opentitan-default-work/bit-copy-placement/winning.vlt').read_text()
    mapped=mapped.replace('// AES runtime-weighted placement; inline zero-reset compiler fix, original RTL/runtime/flags.',
        '// OpenTitan default on eight workers; placement selected using AES runtime profiles.\n'
        '// Worker 0 is the calling/scheduler thread. Required worker-to-CPU affinity: 0 1 2 3 4 5 6 7.\n'
        '// On kk10, workers 0..3 and 4..7 occupy two chiplets on the same socket.\n'
        '// Explicit child units override their enclosing unit; all other logic follows its nearest unit.')
    auto=re.sub(r' -workers \d+->8: \{[^}]*\}', '', mapped)
    auto='`verilator_config\n// OpenTitan module grouping with automatic worker assignment.\n'+ '\n'.join(
        line for line in auto.splitlines() if line.startswith('threads_unit '))+'\n'
    profiles={'original-auto':(WORK/'threads-unit-r5/inputs/OpenTitan-default/units.vlt').read_text(),
              'auto-all':auto,'mapped':mapped}
    for name,text in profiles.items():
        p=ROOT/'profiles'/(name+'.vlt');p.parent.mkdir(exist_ok=True);p.write_text(text)
    assert len(re.findall(r'threads_unit ',mapped))==len(re.findall(r'threads_unit ',auto))
    assert sum(map(int,re.findall(r'-workers (\d+)->8:',mapped)))==54
    return record

def generate(label):
    record=json.loads((ROOT/'opentitan-input.json').read_text())
    dest=ROOT/'models'/label
    dest.mkdir(parents=True,exist_ok=False)
    args=record['args'].copy()
    workers=int(label.rsplit('-',1)[1]);args[args.index('--threads')+1]=str(workers)
    if workers==8:
        profile=label.removeprefix('OpenTitan-default-').removesuffix('-8')
        args+=['--threads-unit-list',str(ROOT/'profiles'/(profile+'.vlt')),
               '--dumpi-V3ExecGraph','4','--debugi-V3OrderParallel','4']
    command=[str(SRC/'bin/verilator'),*args,'--Mdir',str(dest/'obj_dir'),'--no-skip-identical']
    environment=env();environment['VERILATOR_BIN']=str(SRC/'bin/verilator_bin')
    save(dest/'command.json',dict(command=command,cwd=record['cwd'],compiler_sha256=digest(SRC/'bin/verilator_bin')))
    print('START',label,flush=True);start=time.monotonic()
    with (dest/'output.log').open('w') as log:
        result=subprocess.run(command,cwd=record['cwd'],env=environment,stdout=log,stderr=subprocess.STDOUT)
    row=dict(label=label,workers=workers,returncode=result.returncode,seconds=time.monotonic()-start)
    if result.returncode==0:
        stats=(dest/'obj_dir/Vsim__stats.txt').read_text()
        row['lowerings']=int(re.search(r'Lowered bit-copy to part-select\s+(\d+)',stats)[1])
        row['files']={p.name:digest(p) for p in (dest/'obj_dir').iterdir() if p.suffix in ('.cpp','.h','.mk')}
    save(dest/'generation.json',row)
    print('DONE',label,result.returncode,flush=True)
    assert result.returncode==0,dest
    return row

if __name__=='__main__':
    assert json.loads((ROOT/'focused.json').read_text())['passed']
    prepare()
    with ThreadPoolExecutor(max_workers=4) as pool:
        save(ROOT/'opentitan-generation.json',list(pool.map(generate,LABELS)))

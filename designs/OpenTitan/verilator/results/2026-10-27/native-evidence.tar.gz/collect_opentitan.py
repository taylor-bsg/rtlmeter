"""Run on kk10 after completion; collect raw logs and provenance without binaries."""
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

ROOT=Path(__file__).resolve().parent

def read(path):
    return json.loads(path.read_text())

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()

assert not (ROOT/'results/STOP.json').exists()
assert read(ROOT/'results/DONE.json')==dict(passed=True,checks=16,timings=48)
assert read(ROOT/'results/correctness-DONE.json')==dict(passed=True,executions=16)
summaries=list((ROOT/'results/check').rglob('summary.json'))+list((ROOT/'results/timing').rglob('summary.json'))
assert len(summaries)==64
for path in summaries:
    assert read(path)['passed']
    assert read(path.parent/'placement.json')['passed']
machine={}
for name,command in [('lscpu',['lscpu']),('lscpu_extended',['lscpu','-e=CPU,CORE,SOCKET,NODE,CACHE']),
                     ('numactl',['numactl','--hardware']),('clang',['/usr/bin/clang++-21','--version']),
                     ('kernel',['uname','-a'])]:
    machine[name]=subprocess.check_output(command,text=True)
(ROOT/'machine.json').write_text(json.dumps(machine,indent=2)+'\n')
files=[]
for directory in ('results','profiles','provenance'):
    for path in (ROOT/directory).rglob('*'):
        if path.is_file() and (path.suffix in ('.json','.jsonl','.log','.txt','.vlt') or path.name=='check.bin'):
            files.append(path)
for model in (ROOT/'models').iterdir():
    files.extend(model.glob('Vsim__stats.txt'))
    files.extend(model.glob('Vsim__threads_units.txt'))
for name in ('run_opentitan.py','collect_opentitan.py','worker.py','affinity.c','machine.json',
             'source-provenance.json','opentitan-input.json','opentitan-assignment-audit.json',
             'focused.json','binaries.json','payload-manifest.json','progress.log'):
    files.append(ROOT/name)
assert len(files)==len(set(files))
manifest={str(p.relative_to(ROOT)):sha(p) for p in sorted(files)}
archive=ROOT/'evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
    for path in sorted(files):
        tar.add(path,arcname=str(path.relative_to(ROOT)))
    data=(json.dumps(manifest,indent=2)+'\n').encode()
    member=tarfile.TarInfo('evidence-manifest.json');member.size=len(data)
    tar.addfile(member,io.BytesIO(data))
print(json.dumps(dict(archive=str(archive),sha256=sha(archive),bytes=archive.stat().st_size,files=len(files))))

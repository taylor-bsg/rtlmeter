#define _GNU_SOURCE
#include <dlfcn.h>
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <sched.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/resource.h>
#include <sys/syscall.h>
#include <time.h>
#include <unistd.h>

/* Pin threads at creation, outside the simulation's hot path. */
static int cpus[128], count, logfd = -1;
static _Atomic int next_cpu = 1;
static uint64_t start_ns;
static int (*real_create)(pthread_t*, const pthread_attr_t*, void* (*)(void*), void*);

static uint64_t now_ns(void) {
    struct timespec t;
    if (clock_gettime(CLOCK_MONOTONIC, &t)) _exit(120);
    return (uint64_t)t.tv_sec * 1000000000ULL + (uint64_t)t.tv_nsec;
}

__attribute__((constructor)) static void initialize(void) {
    const char* text = getenv("HB_CPUS");
    const char* logfile = getenv("HB_META");
    /* The simulator is pinned; shell/DPI subprocesses must not inherit this shim. */
    unsetenv("LD_PRELOAD");
    if (!text || !logfile) _exit(121);
    char* copy = strdup(text);
    char* token = strtok(copy, ",");
    while (token && count < 128) {
        cpus[count++] = atoi(token);
        token = strtok(NULL, ",");
    }
    free(copy);
    if (!count || token) _exit(122);
    cpu_set_t mask;
    CPU_ZERO(&mask);
    CPU_SET(cpus[0], &mask);
    if (sched_setaffinity(0, sizeof(mask), &mask)) _exit(123);
    real_create = dlsym(RTLD_NEXT, "pthread_create");
    if (!real_create) _exit(124);
    logfd = open(logfile, O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC, 0644);
    if (logfd < 0) _exit(125);
    dprintf(logfd, "{\"event\":\"ready\",\"pid\":%d,\"tid\":%ld,\"cpu\":%d,\"workers\":%d}\n",
            getpid(), syscall(SYS_gettid), sched_getcpu(), count);
    start_ns = now_ns();
    dprintf(logfd, "{\"event\":\"start\",\"monotonic_ns\":%llu,\"cpu\":%d}\n",
            (unsigned long long)start_ns, sched_getcpu());
    /* Let Verilator see the reserved CPUs during its availability check.
       The creator is pinned before the first worker starts below. */
    CPU_ZERO(&mask);
    for (int i = 0; i < count; ++i) CPU_SET(cpus[i], &mask);
    if (sched_setaffinity(0, sizeof(mask), &mask)) _exit(133);
}

int pthread_create(pthread_t* thread, const pthread_attr_t* attr,
                   void* (*entry)(void*), void* arg) {
    /* These validated Verilator models create std::threads with default attrs. */
    if (!real_create || attr) _exit(128);
    int index = atomic_fetch_add(&next_cpu, 1);
    if (index >= count) _exit(129);
    pthread_attr_t local;
    cpu_set_t mask;
    CPU_ZERO(&mask);
    if (index == 1) {
        CPU_SET(cpus[0], &mask);
        if (sched_setaffinity(0, sizeof(mask), &mask)) _exit(134);
        CPU_ZERO(&mask);
    }
    CPU_SET(cpus[index], &mask);
    int rc = pthread_attr_init(&local);
    if (rc) _exit(130);
    rc = pthread_attr_setaffinity_np(&local, sizeof(mask), &mask);
    if (!rc) rc = real_create(thread, &local, entry, arg);
    pthread_attr_destroy(&local);
    if (rc) _exit(131);
    dprintf(logfd, "{\"event\":\"thread_created\",\"index\":%d,\"cpu\":%d,\"monotonic_ns\":%llu}\n", index, cpus[index], (unsigned long long)now_ns());
    return 0;
}

__attribute__((destructor)) static void finish(void) {
    uint64_t end = now_ns();
    struct rusage usage;
    if (!start_ns || logfd < 0 || getrusage(RUSAGE_SELF, &usage)) _exit(132);
    dprintf(logfd, "{\"event\":\"end\",\"monotonic_ns\":%llu,\"elapsed\":%.9f,"
            "\"user_seconds\":%.6f,\"system_seconds\":%.6f,\"max_rss_kib\":%ld,"
            "\"workers\":%d,\"cpu\":%d,\"voluntary_context_switches\":%ld,\"involuntary_context_switches\":%ld}\n",
            (unsigned long long)end, (end - start_ns) / 1e9,
            usage.ru_utime.tv_sec + usage.ru_utime.tv_usec / 1e6,
            usage.ru_stime.tv_sec + usage.ru_stime.tv_usec / 1e6,
            usage.ru_maxrss, atomic_load(&next_cpu), sched_getcpu(), usage.ru_nvcsw, usage.ru_nivcsw);
    close(logfd);
}

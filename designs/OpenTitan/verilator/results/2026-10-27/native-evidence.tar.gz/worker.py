"""LLVM builds and correctness-gated, isolated before/after runs on kk10."""
from concurrent.futures import ThreadPoolExecutor
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import statistics
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
LOCK = Path('/home/mbt-minion/kk-worker/eight-socket/benchmark.lock')
CPU_BASE = int(os.environ.get('BIT_COPY_CPU_BASE','0'))
MEM_NODE = int(os.environ.get('BIT_COPY_MEMORY_NODE','0'))

def read(p): return json.loads(p.read_text())
def digest(p):
    with p.open('rb') as f: return hashlib.file_digest(f, 'sha256').hexdigest()
def save(p, value):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(value, indent=2)+'\n')
def env():
    result = dict(os.environ)
    for k in ('VERILATOR_ROOT','VERILATOR_BIN','MAKEFLAGS','CFLAGS','CXXFLAGS','CPPFLAGS','LDFLAGS','LD_PRELOAD','LD_LIBRARY_PATH','OBJCACHE'):
        result.pop(k, None)
    result.update(CC='/usr/bin/clang-21',CXX='/usr/bin/clang++-21',CCACHE_DISABLE='1',PATH='/usr/local/bin:/usr/bin:/bin')
    return result

def copy_run(case, label, dest):
    os.sched_setaffinity(0,{CPU_BASE})
    workload = read(ROOT/'workloads'/case/'case.json')
    files = [(ROOT/'models'/label/'Vsim','Vsim')]
    files += [(ROOT/'workloads'/case/n,n) for n in workload['files']]
    for source,name in files:
        with source.open('rb') as src, (dest/name).open('xb') as dst:
            shutil.copyfileobj(src,dst,1024*1024)
            dst.flush(); os.fsync(dst.fileno())
        shutil.copymode(source,dest/name)
        assert digest(source)==digest(dest/name)
    save(dest/'binary-copy.json',dict(binary_sha256=digest(dest/'Vsim'),inode=(dest/'Vsim').stat().st_ino,copy_cpu=CPU_BASE))

def build(spec):
    label, slot = spec
    dest=ROOT/'results/builds'/label
    if (dest/'summary.json').exists():
        row=read(dest/'summary.json'); assert row['passed'] and row['binary_sha256']==digest(ROOT/'models'/label/'Vsim')
        return row
    dest.mkdir(parents=True,exist_ok=True)
    command=['taskset','-c',f'{slot*16}-{slot*16+15}','numactl',f'--membind={slot//2}',
        '/usr/bin/make','-f','Vsim.mk','-j16',f'VERILATOR_ROOT={ROOT}/runtime',
        'CC=/usr/bin/clang-21','CXX=/usr/bin/clang++-21','LINK=/usr/bin/clang++-21',
        'CXXFLAGS=-std=gnu++20','CFG_WITH_CCWARN=no','OBJCACHE=','PYTHON3=/usr/bin/python3.12']
    save(dest/'command.json',command)
    print('BUILD',label,flush=True); start=time.monotonic()
    with (dest/'build.log').open('a') as log:
        subprocess.run(command,cwd=ROOT/'models'/label,env=env(),stdout=log,stderr=subprocess.STDOUT,check=True)
    commands=[s for s in (dest/'build.log').read_text().splitlines() if ' -c ' in s or ' -o Vsim' in s]
    assert commands and all(s.startswith('/usr/bin/clang++-21 ') for s in commands)
    assert any(' -o Vsim' in s for s in commands)
    row=dict(passed=True,label=label,seconds=time.monotonic()-start,binary_sha256=digest(ROOT/'models'/label/'Vsim'),clang_commands=len(commands))
    save(dest/'summary.json',row); print('BUILT',label,flush=True)
    return row

def execute(case,label,phase,rep):
    workload=read(ROOT/'workloads'/case/'case.json'); workers=int(label.rsplit('-',1)[1])
    cpus=[CPU_BASE] if workers==1 else list(range(CPU_BASE,CPU_BASE+8))
    dest=ROOT/'results'/phase/case/label/f'round-{rep}'
    dest.mkdir(parents=True,exist_ok=False); (dest/'_execute').mkdir()
    subprocess.run(['taskset','-c',str(CPU_BASE),'numactl',f'--membind={MEM_NODE}','/usr/bin/python3.12',str(ROOT/'worker.py'),'copy',case,label,str(dest)],env=env(),check=True)
    command=['taskset','-c',','.join(map(str,cpus)),'numactl',f'--membind={MEM_NODE}','/usr/bin/env',
        f'LD_PRELOAD={ROOT}/affinity.so',str(dest/'Vsim'),'+verilator+quiet',*workload['args']]
    environment=env(); environment.update(HB_CPUS=','.join(map(str,cpus)),HB_META=str(dest/'affinity.jsonl'),VERILATOR_NUMA_STRATEGY='none')
    save(dest/'command.json',command)
    print('RUN',phase,case,label,rep,flush=True)
    samples=[]; pages=None; start=time.monotonic()
    with (dest/'_execute/stdout.log').open('w') as log:
        p=subprocess.Popen(command,cwd=dest,env=environment,stdout=log,stderr=subprocess.STDOUT)
        try:
            while p.poll() is None:
                assert time.monotonic()-start < 1200, 'Run exceeded 20-minute limit'
                try:
                    events=[json.loads(s) for s in (dest/'affinity.jsonl').read_text().splitlines()]
                    if events and sum(e['event']=='thread_created' for e in events)==workers-1:
                        affinities={t.name:sorted(os.sched_getaffinity(int(t.name))) for t in (Path('/proc')/str(p.pid)/'task').iterdir()}
                        if len(affinities)==workers and all(len(v)==1 for v in affinities.values()):
                            assert sorted(affinities.values())==[[cpu] for cpu in cpus]
                            assert affinities[str(p.pid)]==[CPU_BASE]
                            samples.append(dict(seconds=time.monotonic()-start,affinities=affinities))
                        if pages is None:
                            lines=[s for s in (Path('/proc')/str(p.pid)/'numa_maps').read_text().splitlines() if f'file={dest}/Vsim ' in s]
                            counts={}
                            for line in lines:
                                for node,n in re.findall(r'\bN(\d+)=(\d+)',line): counts[node]=counts.get(node,0)+int(n)
                            if counts:
                                assert set(counts)=={str(MEM_NODE)},counts
                                pages=dict(counts=counts,maps=lines)
                except (FileNotFoundError,ProcessLookupError,json.JSONDecodeError): pass
                time.sleep(.25)
        finally:
            if p.poll() is None: p.kill(); p.wait()
    assert p.returncode==0,(case,label,p.returncode)
    if workload['post']:
        hook=ROOT/'workloads'/case/workload['post']
        with (dest/'post.log').open('w') as log:
            subprocess.run((['/usr/bin/python3.12'] if hook.suffix=='.py' else ['bash'])+[str(hook)],cwd=dest,env=env(),stdout=log,stderr=subprocess.STDOUT,check=True)
    result=dict(output_sha256=digest(dest/'_execute/stdout.log'),clocks=int((dest/'_rtlmeter_cycles.txt').read_text()))
    if (dest/'check.bin').exists(): result['check_sha256']=digest(dest/'check.bin')
    reference=ROOT/'results/references'/f'{case}.json'
    if phase=='check' and label.endswith('-before-1'):
        if reference.exists(): assert read(reference)==result
        else: save(reference,result)
    else: assert read(reference)==result,('Correctness mismatch; do not benchmark',case,label,result,read(reference))
    events=[json.loads(s) for s in (dest/'affinity.jsonl').read_text().splitlines()]
    assert events[-1]['event']=='end' and events[-1]['workers']==workers
    assert [e['cpu'] for e in events if e['event']=='thread_created']==cpus[1:]
    assert samples and pages,'Missing live placement evidence'
    row=dict(passed=True,case=case,label=label,workers=workers,phase=phase,repetition=rep,seconds=events[-1]['elapsed'],
        binary_sha256=digest(dest/'Vsim'),process_metrics=events[-1],cpus=cpus,memory_node=MEM_NODE,**result)
    save(dest/'placement.json',dict(passed=True,samples=samples,executable_pages=pages))
    save(dest/'summary.json',row)
    print('PASS',phase,case,label,rep,f'{row["seconds"]:.6f}s',flush=True)
    return row

if __name__=='__main__':
    if sys.argv[1]=='copy':
        copy_run(sys.argv[2],sys.argv[3],Path(sys.argv[4])); sys.exit(0)
    os.sched_setaffinity(0,{63})
    with LOCK.open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        assert not (ROOT/'results/STOP.json').exists()
        assert 'clang version 21.1.8' in subprocess.check_output(['/usr/bin/clang++-21','--version'],text=True)
        for name,sha in read(ROOT/'payload-manifest.json').items(): assert digest(ROOT/name)==sha,name
        try:
            if sys.argv[1]=='build':
                if not (ROOT/'affinity.so').exists():
                    subprocess.run(['/usr/bin/clang-21','-O2','-shared','-fPIC','-o',str(ROOT/'affinity.so'),str(ROOT/'affinity.c'),'-ldl','-pthread'],env=env(),check=True)
                labels=sys.argv[2:]
                for base in range(0,len(labels),4):
                    with ThreadPoolExecutor(max_workers=4) as pool:
                        list(pool.map(build,[(label,i) for i,label in enumerate(labels[base:base+4])]))
            elif sys.argv[1]=='run':
                case=sys.argv[2]; count=int(sys.argv[3]); labels=sys.argv[4:]
                for label in labels:
                    check=ROOT/'results/check'/case/label/'round-0/summary.json'
                    if check.exists(): assert read(check)['passed'] and read(check)['binary_sha256']==digest(ROOT/'models'/label/'Vsim')
                    else: execute(case,label,'check',0)
                rows=[]
                for rep in range(1,count+1):
                    for label in labels if rep%2 else labels[::-1]:
                        rows.append(execute(case,label,'timing',rep))
                        save(ROOT/'results'/f'{case}-timings.json',rows)
                medians={label:statistics.median(r['seconds'] for r in rows if r['label']==label) for label in labels}
                save(ROOT/'results'/f'{case}-summary.json',dict(passed=True,median_seconds=medians))
                print('MEDIANS',case,json.dumps(medians),flush=True)
            else: raise ValueError(sys.argv[1])
        except BaseException as error:
            save(ROOT/'results/STOP.json',dict(error=repr(error),argv=sys.argv)); raise

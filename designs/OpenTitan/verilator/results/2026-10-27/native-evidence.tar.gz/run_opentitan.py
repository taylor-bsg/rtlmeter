"""Fresh LLVM builds followed by correctness gates and isolated comparison rounds."""
from concurrent.futures import ThreadPoolExecutor
import fcntl
import os
import subprocess
import worker

LABELS=('OpenTitan-default-serial-1','OpenTitan-default-original-auto-8',
        'OpenTitan-default-auto-all-8','OpenTitan-default-mapped-8')
CASES=['OpenTitan-default-'+test for test in ('aes','cmark','rsa','sha')]

if __name__=='__main__':
    os.sched_setaffinity(0,{63})
    with worker.LOCK.open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        try:
            assert 'clang version 21.1.8' in subprocess.check_output(['/usr/bin/clang++-21','--version'],text=True)
            for name,sha in worker.read(worker.ROOT/'payload-manifest.json').items():
                assert worker.digest(worker.ROOT/name)==sha,name
            subprocess.run(['/usr/bin/clang-21','-O2','-shared','-fPIC','-o',str(worker.ROOT/'affinity.so'),
                            str(worker.ROOT/'affinity.c'),'-ldl','-pthread'],env=worker.env(),check=True)
            with ThreadPoolExecutor(max_workers=4) as pool:
                list(pool.map(worker.build,[(label,i) for i,label in enumerate(LABELS)]))
            # Check every configuration/workload before any timing, against immutable prior references.
            for case in CASES:
                for label in LABELS:
                    worker.execute(case,label,'check',0)
            worker.save(worker.ROOT/'results/correctness-DONE.json',dict(passed=True,executions=16))
            rows=[]
            for rep in range(1,4):
                for case in CASES if rep!=2 else CASES[::-1]:
                    for label in LABELS if rep!=2 else LABELS[::-1]:
                        rows.append(worker.execute(case,label,'timing',rep))
                        worker.save(worker.ROOT/'results/timings.json',rows)
            worker.save(worker.ROOT/'results/DONE.json',dict(passed=True,checks=16,timings=len(rows)))
        except BaseException as error:
            worker.save(worker.ROOT/'results/STOP.json',dict(error=repr(error)))
            raise

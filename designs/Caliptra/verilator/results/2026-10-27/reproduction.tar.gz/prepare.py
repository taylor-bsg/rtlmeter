"""Select hierarchy boundaries and retain a disjoint static-cost/connectivity model."""
import collections
import csv
import functools
import re
from common import ROOT, INTEGRATION, read, save, validate_sources

csv.field_size_limit(128*1024*1024)
record=validate_sources()
inventory=INTEGRATION/'inventory/Caliptra'
with (inventory/'instances-all.csv').open() as stream:rows=list(csv.DictReader(stream))
device='caliptra_top_tb.caliptra_top_dut'
modules={r['module'] for r in rows if r['parent']==device and float(r['inclusive_percent'])>=.25}
modules.update(('caliptra_top_tb','__rtlmeter_utils','caliptra_top','caliptra_top_tb_axi_complex',
                'caliptra_top_tb_services','abr_mem_top','ntt_masked_gs_butterfly','ntt_masked_pwm'))
selected=[r for r in rows if r['module'] in modules]
assert len({r['module'] for r in selected})==len(modules)
by_scope={r['instance']:r for r in rows}
prefixes=sorted([r['instance'] for r in selected],key=len,reverse=True)

@functools.lru_cache(None)
def owner(scope):
    return next((p for p in prefixes if scope==p or scope.startswith(p+'.')), 'ROOT')

def decode(name):
    name=name.removeprefix('TOP.').replace('__PVT__','').replace('__DOT__','.').replace('__BRA__','[').replace('__KET__',']')
    return re.sub(r'__0([0-9a-fA-F]{2})',lambda m:chr(int(m[1],16)),name)

costs=collections.Counter()
for row in rows:costs[owner(row['instance'])]+=int(row['own_cost'])
assert sum(costs.values())==read(inventory/'summary.json')['total_cost']
nodes=[dict(instance=r['instance'],module=r['module'],hierarchy_index=int(r['module_index']),
            cost=costs[r['instance']],fixed_worker=0 if r['module'] in ('caliptra_top_tb','__rtlmeter_utils','caliptra_top') else None)
       for r in selected]
nodes.append(dict(instance='ROOT',module='',hierarchy_index=0,cost=costs['ROOT'],fixed_worker=0))
access=collections.defaultdict(lambda:dict(writers=set(),readers=set()))
with (inventory/'hierarchy/obj_dir/work-nba.tsv').open() as stream:
    for row in csv.DictReader(stream,delimiter='\t'):
        unit=owner(decode(row['scope']))
        for column,key in [('writes','writers'),('reads','readers')]:
            for variable in filter(None,row[column].split(';')):access[variable][key].add(unit)
edges=collections.Counter()
for value in access.values():
    terminals=tuple(sorted(value['writers']|value['readers']))
    if value['writers'] and len(terminals)>1:edges[terminals]+=1
save(ROOT/'static-graph.json',dict(nodes=nodes,total_cost=sum(costs.values()),
     edges=[dict(terminals=list(terminals),variables=count) for terminals,count in sorted(edges.items())],
     metric='Distinct shared NBA variables; structural proxy only, no widths or activity weighting',
     load_metric='Disjoint hierarchy-preserved NBA instruction-cost estimates; not runtime'))
profile=ROOT/'profiles/auto.vlt';profile.parent.mkdir(exist_ok=True)
profile.write_text('`verilator_config\n// Caliptra default: crypto/CPU/memory units with automatic placement.\n'
                   '// ABR arithmetic children override their enclosing ABR unit.\n'+
                   ''.join('threads_unit -module "'+module+'"\n' for module in sorted(modules)))
print('Selected module types:',len(modules),'instances:',len(selected),'shared-variable hyperedges:',len(edges))
for n in sorted(nodes,key=lambda n:-n['cost']):
    print(f"{100*n['cost']/sum(costs.values()):7.3f}% {n['instance']}")

"""Preserve exact immutable reference logs and verify the narrowly scoped checker."""
from pathlib import Path
import shutil
import tarfile
from common import ROOT, WORK, TESTS, read, save, digest
from output_check import canonical, MEMORY, STRAPS, ANCHOR

dest=ROOT/'comparison-payload';dest.mkdir(exist_ok=False)
source=(WORK/'bit-copy-suite/worker.py').read_text()
old="else: assert read(reference)==result,('Correctness mismatch; do not benchmark',case,label,result,read(reference))"
assert source.count(old)==1
source=source.replace('import time\n','import time\nfrom output_check import compare\n')
source=source.replace(old,'else: assert compare(case,dest,result,reference)')
(ROOT/'worker_checked.py').write_text(source)
for name in ('worker_checked.py','output_check.py','resume.py','collect.py'):shutil.copy2(ROOT/name,dest/name)
refs=dest/'results/references';refs.mkdir(parents=True)
checks=[]
for test in TESTS:
    case='Caliptra-default-'+test
    old=WORK/'package60-review/remote-evidence/results/check'/case/'Caliptra-default-before-1/round-0/_execute/stdout.log'
    ref=WORK/'package60-review/remote-evidence/results/references'/(case+'.json')
    assert digest(old)==read(ref)['output_sha256']
    data=old.read_bytes();assert data.startswith(MEMORY+STRAPS)
    swapped=STRAPS+MEMORY+data[len(MEMORY+STRAPS):]
    assert canonical(data)==canonical(swapped)
    try:canonical(swapped.replace(b'Iterations: 1',b'Iterations: 2',1))
    except AssertionError:pass
    else:raise AssertionError('Changed startup content accepted')
    changed=swapped.replace(ANCHOR,ANCHOR+b'Unexpected firmware output\n',1)
    assert canonical(changed)!=canonical(data)
    shutil.copy2(old,refs/(case+'.stdout.log'))
    checks.append(dict(case=case,reference_sha256=digest(old),exact_swap_accepted=True,changed_banner_rejected=True,changed_body_rejected=True))
save(ROOT/'output-comparison-tests.json',dict(passed=True,checks=checks))
shutil.copy2(ROOT/'output-comparison-tests.json',dest/'output-comparison-tests.json')
save(dest/'comparison-manifest.json',{str(p.relative_to(dest)):digest(p) for p in dest.rglob('*') if p.is_file()})
with tarfile.open(ROOT/'comparison-payload.tar.gz','w:gz') as tar:
    for path in dest.iterdir():tar.add(path,arcname=path.name)
print('PASS: all four immutable references and negative comparison controls')

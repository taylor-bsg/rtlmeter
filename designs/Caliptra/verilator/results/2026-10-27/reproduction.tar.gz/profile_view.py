"""Create a standalone interactive view of the initial map's call-stack profiles."""
import json
from common import ROOT, REPO, read

data=read(ROOT/'static-callgraph-profile.json')
serial=read(ROOT/'serial-act-breakdown.json')
page='''<!doctype html>
<html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Caliptra: runtime work and waiting</title>
<style>
body{font:16px system-ui,sans-serif;color:#17212b;max-width:1080px;margin:36px auto;padding:0 24px;background:#fafbfc}
h1{font-size:28px}p{line-height:1.55;max-width:920px}.controls{display:flex;align-items:center;gap:12px;margin:24px 0}
select{font:inherit;padding:6px 20px 6px 9px;border:1px solid #a9b2bc;border-radius:5px}.row{display:grid;grid-template-columns:95px 1fr;align-items:center;gap:10px;margin:11px 0}.bar{height:32px;display:flex;background:#ddd;border-radius:3px;overflow:hidden}.segment{height:100%;min-width:0}.legend{display:flex;gap:18px;flex-wrap:wrap;font-size:14px;margin:20px 0}.key{display:inline-block;width:12px;height:12px;margin-right:6px}table{border-collapse:collapse;width:100%;font-size:14px;margin:20px 0}th,td{text-align:left;padding:8px;border-bottom:1px solid #dce2e8}td:last-child,th:last-child{text-align:right}.note{color:#58636e;font-size:14px}code{font-size:13px}h2{font-size:20px;margin-top:30px}
</style>
<h1>Caliptra: runtime work and waiting</h1>
<p>This view shows <b>call-stack samples of the initial static placement</b>, before the revised worker map. Each bar is one worker's sampled cycle distribution. It is not a wall-clock timeline or a profile of the separate serial build.</p>
<div class="controls"><label for="test">Workload</label><select id="test"></select><span id="count" class="note"></span></div>
<div id="bars"></div><div id="legend" class="legend"></div>
<p class="note">Worker 0 is the caller. Workers 0–3 and 4–7 occupy separate chiplets on one socket. ACT executes on the caller; selected NBA units can move between workers. Library copies are attributed using their observed call stacks. Hover over a bar segment for its sampled percentage.</p>
<h2>Attributed NBA unit work</h2>
<p class="note">Shares below use only NBA cycles attributed to a single unit, including attributed library calls. Serial ACT, waiting, unresolved samples, and ambiguous units are excluded. Sampling at 199 Hz and instruction skid limit precision.</p>
<table><thead><tr><th>Instance</th><th>Share of attributed NBA cycles</th></tr></thead><tbody id="units"></tbody></table>
<h2>Caller ACT work by module type</h2><p class="note">This is work that the current worker map does not move. Reused instances of a module type are combined; root/interface work is kept separate.</p>
<table><thead><tr><th>Module type</th><th>Share of sampled ACT cycles</th></tr></thead><tbody id="act"></tbody></table>
<script>
const profiles=PROFILE_DATA;
const serialProfiles=SERIAL_DATA;
const groups=[['Serial ACT','#244d88',['serial_act']],['NBA unit work','#159174',['nba_unit_work']],['Waiting','#c5ccd4',['dispatch_wait','dependency_wait','yield']],['Other / unresolved','#d4983a',[]]];
const select=document.getElementById('test');for(const test of Object.keys(profiles)){const o=document.createElement('option');o.value=test;o.textContent=test.toUpperCase();select.append(o)}
for(const [label,color] of groups){const span=document.createElement('span'),key=document.createElement('i');key.className='key';key.style.background=color;span.append(key,document.createTextNode(label));document.getElementById('legend').append(span)}
function render(){const p=profiles[select.value];document.getElementById('count').textContent=p.samples.toLocaleString()+' samples';const bars=document.getElementById('bars');bars.replaceChildren();for(const worker of p.workers){const row=document.createElement('div');row.className='row';const label=document.createElement('span');label.textContent='Worker '+worker.worker;const bar=document.createElement('div');bar.className='bar';let assigned=0;groups.forEach(([name,color,categories],i)=>{let percent=i===groups.length-1?100-assigned:categories.reduce((sum,k)=>sum+(worker.percentages[k]||0),0);assigned+=percent;const segment=document.createElement('div');segment.className='segment';segment.style.width=percent+'%';segment.style.background=color;segment.title=name+': '+percent.toFixed(1)+'%';bar.append(segment)});row.append(label,bar);bars.append(row)}const body=document.getElementById('units');body.replaceChildren();const units=Object.entries(p.unit_cycles).sort((a,b)=>b[1]-a[1]),total=units.reduce((sum,x)=>sum+x[1],0);for(const [unit,cycles] of units){const row=document.createElement('tr'),name=document.createElement('td'),value=document.createElement('td');name.textContent=unit.replace('caliptra_top_tb.','');value.textContent=(100*cycles/total).toFixed(2)+'%';row.append(name,value);body.append(row)}}
const renderOriginal=render;render=function(){renderOriginal();const body=document.getElementById('act');body.replaceChildren();for(const item of serialProfiles[select.value].module_types){const row=document.createElement('tr'),name=document.createElement('td'),value=document.createElement('td');name.textContent=item.module;value.textContent=item.act_percent.toFixed(2)+'%';row.append(name,value);body.append(row)}};
select.addEventListener('change',render);render();
</script></html>'''
page=page.replace('PROFILE_DATA',json.dumps(data,separators=(',',':')).replace('<','\\u003c'))
page=page.replace('SERIAL_DATA',json.dumps(serial,separators=(',',':')).replace('<','\\u003c'))
target=REPO/'designs/Caliptra/verilator/results/2026-10-27/runtime-profile.html'
target.parent.mkdir(parents=True,exist_ok=True);target.write_text(page)
print(target)

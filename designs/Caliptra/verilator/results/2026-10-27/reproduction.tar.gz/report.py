"""Audit raw measurements independently and stage the validated Caliptra profiles."""
import csv
import hashlib
import json
from pathlib import Path
import re
import shutil
import statistics
import tarfile
from common import ROOT, REPO, TESTS, read, save, digest
from output_check import canonical

evidence=ROOT/'final-evidence'
done=read(evidence/'results/DONE.json');assert done['passed'] and done['rounds']==2 and done['timings']==32
assert not (evidence/'results/STOP.json').exists()
for name,sha in read(evidence/'evidence-manifest.json').items():assert digest(evidence/name)==sha,name
for name,info in read(evidence/'archive-normalization.json')['disassembly_header_normalization'].items():
    restored=re.sub(rb'^Vsim(:[ \t]+file format)',lambda m:info['original_header_path'].encode()+m[1],
                    (evidence/name).read_bytes(),count=1,flags=re.M)
    assert hashlib.sha256(restored).hexdigest()==info['original_sha256'],name
labels=done['labels'];selected=labels[-1];kind=done['kind']
assert read(ROOT/(kind+'-assignment-audit.json'))['passed']
assert read(ROOT/'portable-equivalence.json')['passed']
assert read(ROOT/'workload-audit.json')['passed']
builds={label:read(evidence/'results/builds'/label/'summary.json') for label in labels}
for label,row in builds.items():
    assert row['passed'];command=read(evidence/'results/builds'/label/'command.json')
    for expected in ['CC=/usr/bin/clang-21','CXX=/usr/bin/clang++-21','LINK=/usr/bin/clang++-21','CXXFLAGS=-std=gnu++20']:assert expected in command
    commands=[line for line in (evidence/'results/builds'/label/'build.log').read_text().splitlines() if ' -c ' in line or ' -o Vsim' in line]
    assert len(commands)==row['clang_commands'] and all(line.startswith('/usr/bin/clang++-21 ') for line in commands)
timings=[];audited=[];inodes=set();summary=[]
for test in TESTS:
    case='Caliptra-default-'+test;reference=read(evidence/'results/references'/(case+'.json'))
    baseline=(evidence/'results/references'/(case+'.stdout.log')).read_bytes()
    assert hashlib.sha256(baseline).hexdigest()==reference['output_sha256']
    for label in labels:
        workers=int(label.rsplit('-',1)[1]);times=[]
        gate='candidate-check' if label==selected else 'check-reviewed'
        for phase,reps in [(gate,[0]),('timing',[1,2])]:
            for rep in reps:
                dest=evidence/'results'/phase/case/label/f'round-{rep}'
                row=read(dest/'summary.json');placement=read(dest/'placement.json');copied=read(dest/'binary-copy.json')
                assert row['passed'] and placement['passed']
                assert row['binary_sha256']==copied['binary_sha256']==builds[label]['binary_sha256']
                assert row['output_sha256']==digest(dest/'_execute/stdout.log')
                assert canonical((dest/'_execute/stdout.log').read_bytes())==canonical(baseline)
                assert read(dest/'output-comparison.json')['canonical_output_sha256']==hashlib.sha256(canonical(baseline)).hexdigest()
                assert row['clocks']==reference['clocks']==int((dest/'_rtlmeter_cycles.txt').read_text())
                events=[json.loads(line) for line in (dest/'affinity.jsonl').read_text().splitlines()]
                assert events[-1]['event']=='end' and events[-1]['workers']==workers
                assert row['seconds']==events[-1]['elapsed']>0
                assert [e['cpu'] for e in events if e['event']=='thread_created']==list(range(1,workers))
                assert row['cpus']==list(range(workers)) and row['memory_node']==0
                assert placement['samples'] and set(placement['executable_pages']['counts'])=={'0'}
                for sample in placement['samples']:assert sorted(sample['affinities'].values())==[[i] for i in range(workers)]
                assert copied['copy_cpu']==0 and copied['inode'] not in inodes;inodes.add(copied['inode'])
                side=read(dest/'side-output-comparison.json');assert side['passed']
                for name,sha in side['sha256'].items():assert digest(dest/name)==sha,name
                assert digest(dest/'console.log')==digest(evidence/'side-references'/(case+'.console.log'))
                for name in ('lmem_data_dump.hex','dccm_data_dump.hex','iccm_data_dump.hex'):
                    assert digest(dest/name)==digest(evidence/'results/check-reviewed'/case/'Caliptra-default-serial-1/round-0'/name)
                audited.append(row)
                if phase=='timing':times.append(row['seconds']);timings.append(row)
        summary.append(dict(case=case,label=label,workers=workers,median_seconds=statistics.median(times),
                            minimum_seconds=min(times),maximum_seconds=max(times),samples_seconds=times,clocks=reference['clocks']))
assert len(timings)==32 and len(audited)==48
key=lambda r:(r['case'],r['label'],r['repetition'])
assert sorted(timings,key=key)==sorted(read(evidence/'results/timings.json'),key=key)
for test in TESTS:
    case='Caliptra-default-'+test;serial=next(row['median_seconds'] for row in summary if row['case']==case and row['workers']==1)
    for row in summary:
        if row['case']==case:row['speedup_vs_one_worker']=serial/row['median_seconds']
save(ROOT/'native-audit.json',dict(passed=True,independent_raw_evidence_audit=True,timed_runs=32,comparison_correctness_gates=16,
    initial_gate_runs=read(evidence/'results/correctness-DONE.json')['executions'],
    revised_map_gate_runs=len(read(evidence/'results/runtime-candidate-DONE.json')['checks']),
    unique_executable_inodes=len(inodes),clang_only=True,live_worker_affinity_and_node_zero_checked=True,
    normalized_disassembly_headers_reconstruct_to_original_hashes=True,
    console_and_memory_snapshot_checks=True,output_rule='Exact except for the documented two time-zero banners exchanging order'))
save(ROOT/'summary.json',dict(passed=True,selected=selected,configurations=summary))

target=REPO/'designs/Caliptra/verilator/results/2026-10-27';target.mkdir(parents=True,exist_ok=True)
shutil.copy2(ROOT/'profiles/portable.vlt',target.parent.parent/'threads-unit.vlt')
shutil.copy2(ROOT/'profiles'/(kind+'.vlt'),target.parent.parent/'threads-unit-kk10.vlt')
for name in ('native-audit.json','summary.json','source-provenance.json','input.json','staged-source-audit.json',
             'workload-audit.json','portable-equivalence.json','output-comparison-tests.json','static-graph.json',
             'static-placement.json','static-assignment-audit.json','static-runtime-profile.json','static-callgraph-profile.json','serial-act-breakdown.json',
             kind+'-placement.json',kind+'-assignment-audit.json'):
    shutil.copy2(ROOT/name,target/name)
shutil.copy2(ROOT/'models'/selected/'obj_dir/Vsim__threads_units.txt',target/'threads-unit-indices.txt')
shutil.copy2(ROOT/'profiles/static.vlt',target/'initial-static.vlt')
shutil.copy2(ROOT/'evidence-final.tar.gz',target/'native-evidence.tar.gz')
with (target/'timings.csv').open('w',newline='') as stream:
    fields=['case','label','workers','repetition','seconds','clocks','output_sha256','binary_sha256']
    writer=csv.DictWriter(stream,fieldnames=fields,extrasaction='ignore',lineterminator='\n');writer.writeheader();writer.writerows(timings)
with tarfile.open(target/'reproduction.tar.gz','w:gz',compresslevel=6) as tar:
    for path in sorted(ROOT.glob('*.py')):tar.add(path,arcname=path.name)
    for label in labels+['Caliptra-default-static-8','Caliptra-default-portable-8']:
        for name in ('generation.json','command.json'):
            path=ROOT/'models'/label/name;tar.add(path,arcname=str(path.relative_to(ROOT)))
    for path in sorted((ROOT/'profiles').glob('*.vlt')):tar.add(path,arcname=str(path.relative_to(ROOT)))
headers=['Workload','1 worker (s)','Default 8 (s)','Same units, auto 8 (s)','Mapped 8 (s)','Speedup vs. 1 worker']
table='| '+' | '.join(headers)+' |\n|---|---:|---:|---:|---:|---:|\n'
for test in TESTS:
    values=[next(row for row in summary if row['case']=='Caliptra-default-'+test and row['label']==label) for label in labels]
    table+='| '+' | '.join([test]+[f'{row["median_seconds"]:.3f}' for row in values]+[f'{values[-1]["speedup_vs_one_worker"]:.2f}x'])+' |\n'
(ROOT/'result-table.md').write_text(table)
print(table)

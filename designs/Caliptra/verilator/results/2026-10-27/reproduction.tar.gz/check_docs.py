"""Validate local result links and build the complete RTLMeter documentation."""
import hashlib
from pathlib import Path
import re
from sphinx.application import Sphinx

root=Path(__file__).resolve().parent
repo=root.parent/'rtlmeter-unit-profiles';source=repo/'docs/source'
target=repo/'designs/Caliptra/verilator/results/2026-10-27'
for link in re.findall(r'\]\(([^)]+)\)',(target/'RESULTS.md').read_text()):
    if '://' not in link and not link.startswith('#'):assert (target/link.split('#')[0]).is_file(),link
with (root/'documentation-build.log').open('w') as stream:
    app=Sphinx(str(source),str(source),str(root/'docs-html'),str(root/'docs-doctrees'),'html',
               confoverrides={'extensions':[]},status=stream,warning=stream,warningiserror=True,freshenv=True)
    app.build(force_all=True);assert app.statuscode==0,'See documentation-build.log'
files=sorted(p for p in target.iterdir() if p.is_file() and p.name!='SHA256SUMS')
assert all(p.stat().st_size<100_000_000 for p in files)
manifest=''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in files)
(target/'SHA256SUMS').write_text(manifest)
print('PASS: local result links, full Sphinx HTML build,',len(files),'artifact hashes')

"""Resume correctness checks after narrowly diagnosing initial banner reordering."""
import fcntl
import os
from pathlib import Path
import shutil
import run_remote
import worker_checked as worker

run_remote.worker=worker
if __name__=='__main__':
    os.sched_setaffinity(0,{63})
    with worker.LOCK.open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        try:
            for name,sha in worker.read(worker.ROOT/'comparison-manifest.json').items():assert worker.digest(worker.ROOT/name)==sha,name
            stopped=worker.ROOT/'results/STOP.json'
            assert stopped.exists() and 'Correctness mismatch' in worker.read(stopped)['error']
            history=worker.ROOT/'results/stops';history.mkdir(exist_ok=True)
            stopped.rename(history/'initial-output-order.json')
            for case in run_remote.CASES:
                for label in run_remote.LABELS:
                    worker.execute(case,label,'check-reviewed',0)
            worker.save(worker.ROOT/'results/correctness-DONE.json',dict(passed=True,executions=16,phase='check-reviewed',comparison='two exact time-zero blocks may swap; all remaining output and cycles are exact'))
            profiles=[run_remote.sample(case,'Caliptra-default-static-8') for case in run_remote.CASES]
            worker.save(worker.ROOT/'results/profiling-DONE.json',dict(passed=True,profiles=profiles))
        except BaseException as error:
            worker.save(worker.ROOT/'results/STOP.json',dict(error=repr(error)));raise

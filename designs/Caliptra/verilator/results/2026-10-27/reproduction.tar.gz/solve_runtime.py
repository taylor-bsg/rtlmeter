"""Balance measured NBA unit work across all four workloads, then reduce cuts."""
import collections
import shlex
from ortools.sat.python import cp_model
from common import ROOT, TESTS, read, save

profiles=read(ROOT/'static-callgraph-profile.json');assert set(profiles)==set(TESTS)
graph=read(ROOT/'static-graph.json');nodes=graph['nodes'];static=read(ROOT/'static-placement.json')['mapping']
actual={s for m,i,w,s,p in (shlex.split(line) for line in (ROOT/'models/Caliptra-default-static-8/obj_dir/Vsim__threads_units.txt').read_text().splitlines() if line and not line.startswith('#'))}
weights={}
for test,p in profiles.items():
    ambiguous=sum(p['ambiguous_cycles'].values());known=sum(p['unit_cycles'].values())
    assert ambiguous/(ambiguous+known)<.10,(test,'Too much ambiguous unit work for a placement model')
    cost=p['unit_cycles'];total=sum(cost.get(n['instance'],0) for n in nodes if n['instance'] in actual)
    weights[test]=[round(100000*cost.get(n['instance'],0)/total) if n['instance'] in actual else 0 for n in nodes]
model=cp_model.CpModel();x=[[model.new_bool_var(f'n{i}w{w}') for w in range(8)] for i in range(len(nodes))]
for i,n in enumerate(nodes):
    model.add_exactly_one(x[i])
    if n['fixed_worker'] is not None:model.add(x[i][n['fixed_worker']]==1)
    # Call stacks identify memory-copy work in both caller ACT and these NBA
    # units. Keep their NBA evaluation on the caller's chiplet; place AXI
    # evaluation on the caller itself to test hot-state reuse between phases.
    if n['module']=='caliptra_top_tb_axi_complex':model.add(x[i][0]==1)
    elif n['module'] in ('abr_mem_top','kv'):model.add(sum(x[i][:4])==1)
    for w in range(8):model.add_hint(x[i][w],int(static[n['instance']]==w))
loads={};high=model.new_int_var(0,100100,'worst_worker')
for test,costs in weights.items():
    loads[test]=[model.new_int_var(0,100100,f'{test}_load{w}') for w in range(8)]
    for w in range(8):
        model.add(loads[test][w]==sum(cost*x[i][w] for i,cost in enumerate(costs)))
        model.add(high>=loads[test][w])
model.minimize(high)
solver=cp_model.CpSolver();solver.parameters.num_search_workers=8;solver.parameters.max_time_in_seconds=45
status=solver.solve(model);assert status in (cp_model.FEASIBLE,cp_model.OPTIMAL)
first=dict(status=solver.status_name(status),worst_worker=solver.value(high),bound=solver.best_objective_bound,
           loads={t:[solver.value(v) for v in ls] for t,ls in loads.items()})
hint=[[solver.value(v) for v in row] for row in x]
model.clear_hints()
for row,hints in zip(x,hint):
    for v,h in zip(row,hints):model.add_hint(v,h)
model.add(high<=round(first['worst_worker']*1.03))
objective=[];by_name={n['instance']:i for i,n in enumerate(nodes)}
for test,ls in loads.items():
    # Favor <=3% chiplet imbalance without making the multi-workload model infeasible.
    excess=model.new_int_var(0,100100,test+'_chiplet_excess')
    a=sum(ls[:4]);b=sum(ls[4:]);model.add(excess*100>=100*a-103*b);model.add(excess*100>=100*b-103*a)
    objective.append(1000*excess)
for e,edge in enumerate(graph['edges']):
    ids=[by_name[name] for name in edge['terminals']];used=[]
    for w in range(8):
        v=model.new_bool_var(f'e{e}w{w}');model.add_max_equality(v,[x[i][w] for i in ids]);used.append(v)
    sides=[]
    for c in range(2):
        v=model.new_bool_var(f'e{e}c{c}');model.add_max_equality(v,used[4*c:4*c+4]);sides.append(v)
    objective.append(edge['variables']*(sum(used)-1+4*(sum(sides)-1)))
model.minimize(sum(objective));solver.parameters.max_time_in_seconds=45
status=solver.solve(model);assert status in (cp_model.FEASIBLE,cp_model.OPTIMAL)
mapping={n['instance']:next(w for w in range(8) if solver.value(x[i][w])) for i,n in enumerate(nodes)}
result=dict(stage1=first,status=solver.status_name(status),objective=solver.objective_value,bound=solver.best_objective_bound,
    mapping=mapping,loads={t:[solver.value(v) for v in ls] for t,ls in loads.items()},weights=weights,
    metric='Per-workload normalized sampled NBA cycles, including library work attributed by call stacks; serial and ambiguous work excluded',
    locality_constraints='AXI testbench memory on caller 0; ABR memory and key vault on chiplet 0. These are hypotheses from sampled ACT/NBA copy costs, not solver-proven latency optima.',
    criterion='Under the memory-locality constraints, minimize worst worker fraction across all four workloads, allow 3% slack, then prioritize chiplet balance and structural shared-variable cuts')
save(ROOT/'runtime-placement.json',result)
units=collections.defaultdict(list)
for line in (ROOT/'models/Caliptra-default-static-8/obj_dir/Vsim__threads_units.txt').read_text().splitlines():
    if not line or line.startswith('#'):continue
    module,index,worker,scope,pattern=shlex.split(line);units[module].append((int(index),mapping[scope]))
lines=['`verilator_config','// Caliptra default: placement based on measured NBA work across four workloads.',
       '// Worker 0 is the caller. Workers 0-3 and 4-7 occupy two kk10 chiplets.']
for module,entries in sorted(units.items()):
    entries.sort();lines.append(f'threads_unit -module "{module}" -workers {len(entries)}->8: {{ '+' '.join(str(w) for i,w in entries)+' }')
(ROOT/'profiles/runtime.vlt').write_text('\n'.join(lines)+'\n')
print('FIRST',first);print('FINAL',result['status'],result['loads'])
for w in range(8):print(w,[(n['module'],n['hierarchy_index']) for n in nodes if mapping[n['instance']]==w])

"""Describe which module types consume caller ACT samples, without moving them."""
import collections
import re
import shlex
from common import ROOT, TESTS, read, save

units=ROOT/'models/Caliptra-default-static-8/obj_dir/Vsim__threads_units.txt'
modules=sorted({shlex.split(line)[0] for line in units.read_text().splitlines() if line and not line.startswith('#')},key=len,reverse=True)
rows={}
for test in TESTS:
    run=ROOT/'remote-evidence/results/callgraph'/('Caliptra-default-'+test)/'Caliptra-default-static-8/round-1'
    main=next(int(t) for t,c in read(run/'placement.json')['samples'][0]['affinities'].items() if c==[0])
    totals=collections.Counter();symbols=collections.Counter();copies=collections.Counter();total=0
    for block in (run/'samples.txt').read_text().split('\n\n'):
        lines=block.splitlines()
        if not lines:continue
        header=re.fullmatch(r'\s*(\d+)/(\d+)\s+(\d+)\s*',lines[0]);assert header
        if int(header[2])!=main:continue
        period=int(header[3]);frames=[]
        for line in lines[1:]:
            m=re.fullmatch(r'\s*([0-9a-f]+) (.+) \(([^()]*)\)',line);assert m,line
            frames.append(m[2].split('(')[0])
        if not any(f.startswith('Vsim___024root___eval_') and '__act' in f for f in frames):continue
        if any('Vthread__nba' in f or 'nba_mtask' in f for f in frames):continue
        total+=period
        parent=next((f for f in frames if f.startswith('Vsim_')),None)
        module=next((m for m in modules if parent and parent.startswith('Vsim_'+m+'_')),'root/interface/other')
        totals[module]+=period;symbols[parent or '[no generated caller]']+=period
        if frames and any(name in frames[0] for name in ('memmove','memcpy','memset')):copies[module]+=period
    rows[test]=dict(total_act_cycles=total,
        module_types=[dict(module=m,cycles=c,act_percent=100*c/total,library_copy_cycles=copies[m],library_copy_act_percent=100*copies[m]/total) for m,c in totals.most_common()],
        top_functions=[dict(function=f,act_percent=100*c/total) for f,c in symbols.most_common(20)],
        caveat='Module-type attribution from the nearest generated function in sampled ACT stacks; reused instances are combined. Root/interface work is not reassigned to an inferred source instance.')
    print(test,[(r['module'],round(r['act_percent'],1)) for r in rows[test]['module_types'][:8]])
save(ROOT/'serial-act-breakdown.json',rows)

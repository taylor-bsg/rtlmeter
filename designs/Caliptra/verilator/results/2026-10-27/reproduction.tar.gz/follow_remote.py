"""Validate a runtime-based candidate and time the selected map with fair controls."""
import fcntl
import os
import sys
import run_remote
import worker_checked as worker
import side_outputs

run_remote.worker=worker
def execute(case,label,phase,rep):
    row=worker.execute(case,label,phase,rep)
    dest=worker.ROOT/'results'/phase/case/label/f'round-{rep}'
    side_outputs.check(case,dest)
    return row

if __name__=='__main__':
    action,kind=sys.argv[1:3];label=f'Caliptra-default-{kind}-8'
    os.sched_setaffinity(0,{63})
    with worker.LOCK.open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        try:
            assert not (worker.ROOT/'results/STOP.json').exists()
            assert worker.read(worker.ROOT/'results/profiling-DONE.json')['passed']
            for name,sha in worker.read(worker.ROOT/(kind+'-manifest.json')).items():assert worker.digest(worker.ROOT/name)==sha,name
            for case in run_remote.CASES:
                for control in run_remote.LABELS:
                    dest=worker.ROOT/'results/check-reviewed'/case/control/'round-0'
                    assert worker.read(dest/'summary.json')['passed'];side_outputs.check(case,dest)
            if action=='candidate':
                worker.build((label,0))
                rows=[execute(case,label,'candidate-check',0) for case in run_remote.CASES]
                worker.save(worker.ROOT/'results'/(kind+'-candidate-DONE.json'),dict(passed=True,checks=rows))
                # One diagnostic run confirms that the proposed worker balance actually changed.
                run_remote.sample(run_remote.CASES[0],label)
                side_outputs.check(run_remote.CASES[0],worker.ROOT/'results/samples'/run_remote.CASES[0]/label/'round-1')
                worker.save(worker.ROOT/'results'/(kind+'-profile-DONE.json'),dict(passed=True))
            elif action=='timing':
                assert worker.read(worker.ROOT/'results'/(kind+'-candidate-DONE.json'))['passed']
                labels=['Caliptra-default-serial-1','Caliptra-default-default-8','Caliptra-default-auto-8',label]
                rows=[]
                for rep in (1,2):
                    for case in run_remote.CASES if rep==1 else run_remote.CASES[::-1]:
                        for control in labels if rep==1 else labels[::-1]:
                            rows.append(execute(case,control,'timing',rep))
                            worker.save(worker.ROOT/'results/timings.json',rows)
                worker.save(worker.ROOT/'results/DONE.json',dict(passed=True,kind=kind,labels=labels,rounds=2,timings=len(rows)))
            else:raise ValueError(action)
        except BaseException as error:
            worker.save(worker.ROOT/'results/STOP.json',dict(error=repr(error)));raise

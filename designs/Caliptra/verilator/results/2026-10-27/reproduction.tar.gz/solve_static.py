"""Bounded CP-SAT search for a balanced initial placement; not a runtime model."""
import collections
import shlex
from ortools.sat.python import cp_model
from common import ROOT, read, save

graph=read(ROOT/'static-graph.json'); nodes=graph['nodes']; total=graph['total_cost']
model=cp_model.CpModel()
x=[[model.new_bool_var(f'n{i}w{w}') for w in range(8)] for i in range(len(nodes))]
for i,node in enumerate(nodes):
    model.add_exactly_one(x[i])
    if node['fixed_worker'] is not None:model.add(x[i][node['fixed_worker']]==1)
loads=[model.new_int_var(0,total,f'load{w}') for w in range(8)]
for w in range(8):model.add(loads[w]==sum(n['cost']*x[i][w] for i,n in enumerate(nodes)))
high=model.new_int_var(0,total,'high');low=model.new_int_var(0,total,'low')
model.add_max_equality(high,loads);model.add_min_equality(low,loads)
chiplet=sum(loads[4:]);model.add(chiplet*203>=100*total);model.add(chiplet*203<=103*total)
# Break symmetry inside each chiplet, keeping caller worker 0 distinct.
for a,b in ((1,2),(2,3),(4,5),(5,6),(6,7)):model.add(loads[a]>=loads[b])
model.minimize(high-low)
solver=cp_model.CpSolver();solver.parameters.max_time_in_seconds=45;solver.parameters.num_search_workers=8
status=solver.solve(model);assert status in (cp_model.FEASIBLE,cp_model.OPTIMAL)
first=dict(status=solver.status_name(status),spread=solver.value(high-low),bound=solver.best_objective_bound,
           loads=[solver.value(v) for v in loads])
initial=[[solver.value(v) for v in row] for row in x]
# Permit at most 3% of the ideal per-worker load beyond the best spread found.
model.add(high-low<=first['spread']+round(total/8*.03))
by_name={n['instance']:i for i,n in enumerate(nodes)}
objective=[]
for e,edge in enumerate(graph['edges']):
    ids=[by_name[name] for name in edge['terminals']]
    used=[]
    for w in range(8):
        v=model.new_bool_var(f'e{e}w{w}');model.add_max_equality(v,[x[i][w] for i in ids]);used.append(v)
    sides=[]
    for c in range(2):
        v=model.new_bool_var(f'e{e}c{c}');model.add_max_equality(v,used[4*c:4*c+4]);sides.append(v)
    objective.append(edge['variables']*(sum(used)-1+4*(sum(sides)-1)))
for row,hints in zip(x,initial):
    for v,hint in zip(row,hints):model.add_hint(v,hint)
model.minimize(sum(objective));solver.parameters.max_time_in_seconds=45
status=solver.solve(model);assert status in (cp_model.FEASIBLE,cp_model.OPTIMAL)
mapping={n['instance']:next(w for w in range(8) if solver.value(x[i][w])) for i,n in enumerate(nodes)}
result=dict(stage1=first,status=solver.status_name(status),objective=solver.objective_value,
            bound=solver.best_objective_bound,loads=[solver.value(v) for v in loads],mapping=mapping,
            criterion='Minimize shared-variable worker cuts plus 4x shared-variable chiplet cuts, within a bounded static-cost spread; chiplet cost ratio <=1.03')
save(ROOT/'static-placement.json',result)
units=collections.defaultdict(list)
for line in (ROOT/'models/Caliptra-default-auto-8/obj_dir/Vsim__threads_units.txt').read_text().splitlines():
    if not line or line.startswith('#'):continue
    module,index,worker,scope,pattern=shlex.split(line)
    units[module].append((int(index),mapping[scope]))
lines=['`verilator_config','// Initial Caliptra default placement from static costs and NBA connectivity.',
       '// Workers 0-3 and 4-7 use separate chiplets; worker 0 is the caller.']
for module,entries in sorted(units.items()):
    entries.sort();assert [i for i,w in entries]==list(range(len(entries)))
    lines.append(f'threads_unit -module "{module}" -workers {len(entries)}->8: {{ '+ ' '.join(str(w) for i,w in entries)+' }')
(ROOT/'profiles/static.vlt').write_text('\n'.join(lines)+'\n')
print('FIRST',first,flush=True)
print('FINAL',result['status'],result['loads'],'chiplet ratio',max(sum(result['loads'][:4]),sum(result['loads'][4:]))/min(sum(result['loads'][:4]),sum(result['loads'][4:])),flush=True)
for w in range(8):print(w,[(n['module'],n['hierarchy_index']) for n in nodes if mapping[n['instance']]==w])

"""Audit firmware console against immutable evidence and snapshots against serial."""
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def check(case,dest):
    baseline=ROOT/'results/check-reviewed'/case/'Caliptra-default-serial-1/round-0'
    console=ROOT/'side-references'/(case+'.console.log')
    manifest=json.loads((ROOT/'side-reference-manifest.json').read_text())
    assert sha(console)==manifest[str(console.relative_to(ROOT))]
    hashes={}
    for name in ('console.log','lmem_data_dump.hex','dccm_data_dump.hex','iccm_data_dump.hex'):
        reference=console if name=='console.log' else baseline/name
        hashes[name]=sha(reference)
        assert sha(dest/name)==hashes[name],('Side output mismatch; stop benchmarking',str(dest),name)
    (dest/'side-output-comparison.json').write_text(json.dumps(dict(passed=True,sha256=hashes),indent=2)+'\n')
    return hashes

if __name__=='__main__':
    paths=[]
    for phase in ('check-reviewed','samples','candidate-check','probe','timing'):
        for path in (ROOT/'results'/phase).rglob('summary.json'):
            row=json.loads(path.read_text());assert row['passed'];check(row['case'],path.parent);paths.append(str(path.parent.relative_to(ROOT)))
    (ROOT/'side-output-audit.json').write_text(json.dumps(dict(passed=True,runs=paths),indent=2)+'\n')
    print('PASS: console and memory snapshots for',len(paths),'completed runs')

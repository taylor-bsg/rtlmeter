"""Audit emitted scope arguments and worker dispatch, not merely the VLT listing."""
import collections
import csv
import re
import shlex
import sys
from common import ROOT, WORK, INTEGRATION, read, save, digest

kind=sys.argv[1] if len(sys.argv)>1 else 'static'
obj=ROOT/'models'/f'Caliptra-default-{kind}-8'/'obj_dir'
def listing(path):return [shlex.split(line) for line in path.read_text().splitlines() if line and not line.startswith('#')]
actual={scope:(module,int(index),int(worker)) for module,index,worker,scope,pattern in listing(obj/'Vsim__threads_units.txt')}
mapping=read(ROOT/(kind+'-placement.json'))['mapping']
assert all(worker==mapping[scope] for scope,(module,index,worker) in actual.items())
auto=listing(ROOT/'models/Caliptra-default-auto-8/obj_dir/Vsim__threads_units.txt')
assert {(m,int(i),s) for m,i,w,s,p in auto}=={(m,i,s) for s,(m,i,w) in actual.items()}
expected=dict(actual);expected['caliptra_top_tb']=('caliptra_top_tb',0,0)
body=(WORK/'thread-unit-profile-followup/dispatch-audit-body.py').read_text().replace('chip_sim_tb','caliptra_top_tb')
body=body.replace('name.startswith("caliptra_top_tb")','re.match(r"(?:__Vdly(?:_Mask)?__)?caliptra_top_tb__DOT__", name)')
# The top module is not a selectable unit: its residual tasks remain automatically
# scheduled. The zero-NBA utility may have no emitted task.
body=body.replace('if scope == "caliptra_top_tb":\n        assert owners[scope] <= {0}, (scope, owners[scope])',
                  'if scope == "caliptra_top_tb":\n        pass\n    elif scope == "caliptra_top_tb.__rtlmeter_utils_u":\n        assert owners[scope] <= {0}, (scope, owners[scope])')
namespace=dict(collections=collections,csv=csv,re=re,WORK=INTEGRATION/'inventory/Caliptra',OBJ=obj,expected=expected)
exec(compile(body,str(ROOT/'dispatch-audit-body.py'),'exec'),namespace)
save(ROOT/(kind+'-assignment-audit.json'),dict(passed=True,units=len(actual),task_count=len(namespace['tasks']),
    listing_sha256=digest(obj/'Vsim__threads_units.txt'),
    owners={scope:sorted(workers) for scope,workers in namespace['owners'].items()},
    schedules=namespace['schedules'],tasks={str(k):sorted(v) for k,v in namespace['tasks'].items()},
    scope='Parallel NBA dispatch for selected units; residual top-level tasks are automatic. Serial ACT stays on the caller. Utility has zero static NBA cost.',
    same_unit_auto_control_matches_inventory=True,all_emitted_unit_dispatch_owners_match=True))
(ROOT/'dispatch-audit-body.py').write_text(body)
print('Dispatch audit passed:',len(actual),'units;',len(namespace['tasks']),'tasks')

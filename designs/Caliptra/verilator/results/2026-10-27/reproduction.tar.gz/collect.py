"""Capture raw remote evidence; optional partial snapshots retain completed runs."""
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import sys
import tarfile

ROOT=Path(__file__).resolve().parent
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def read(path):return json.loads(path.read_text())
phase=sys.argv[1]
if phase=='final':assert read(ROOT/'results/DONE.json')['passed']
elif phase=='profiles':assert read(ROOT/'results/profiling-DONE.json')['passed']
assert not (ROOT/'results/STOP.json').exists()
machine={name:subprocess.check_output(command,text=True) for name,command in [
    ('lscpu',['lscpu']),('lscpu_extended',['lscpu','-e=CPU,CORE,SOCKET,NODE,CACHE']),
    ('numactl',['numactl','--hardware']),('clang',['/usr/bin/clang++-21','--version']),('kernel',['uname','-a'])]}
(ROOT/'machine.json').write_text(json.dumps(machine,indent=2)+'\n')
files=[]
for directory in ('results','profiles','provenance','side-references'):
    for path in (ROOT/directory).rglob('*'):
        if path.is_file() and (path.suffix in ('.json','.jsonl','.log','.txt','.vlt') or path.name.endswith('_data_dump.hex')):files.append(path)
for model in (ROOT/'models').iterdir():
    files.extend(model.glob('Vsim__stats.txt'));files.extend(model.glob('Vsim__threads_units.txt'))
for path in ROOT.iterdir():
    if path.is_file() and path.suffix in ('.py','.c','.json','.log'):files.append(path)
assert len(files)==len(set(files))
archive=ROOT/('evidence-'+phase+'.tar.gz')
with tarfile.open(archive,'w:gz',compresslevel=3) as tar:
    manifest={};seen={};normalizations={}
    for path in sorted(files):
        # Read once so a growing progress log cannot invalidate its own archive hash.
        data=path.read_bytes();name=str(path.relative_to(ROOT))
        if path.name=='disassembly.txt':
            pattern=rb'^(/[^\n]+/Vsim)(:[ \t]+file format [^\n]+)$'
            match=re.search(pattern,data,re.M);assert match,name
            normalizations[name]=dict(original_sha256=hashlib.sha256(data).hexdigest(),original_header_path=match[1].decode(),replacement='Vsim')
            data=re.sub(pattern,rb'Vsim\2',data,count=1,flags=re.M)
        digest=hashlib.sha256(data).hexdigest();manifest[name]=digest
        member=tarfile.TarInfo(name)
        if digest in seen:
            member.type=tarfile.LNKTYPE;member.linkname=seen[digest];tar.addfile(member)
        else:
            member.size=len(data);tar.addfile(member,io.BytesIO(data));seen[digest]=name
    data=(json.dumps(dict(disassembly_header_normalization=normalizations,
                         note='Only objdump output-path headers are normalized; instruction bytes/text are unchanged. Identical files are stored as tar hard links.'),indent=2)+'\n').encode()
    name='archive-normalization.json';manifest[name]=hashlib.sha256(data).hexdigest()
    member=tarfile.TarInfo(name);member.size=len(data);tar.addfile(member,io.BytesIO(data))
    data=(json.dumps(manifest,indent=2)+'\n').encode();member=tarfile.TarInfo('evidence-manifest.json');member.size=len(data)
    tar.addfile(member,io.BytesIO(data))
print(json.dumps(dict(path=str(archive),bytes=archive.stat().st_size,sha256=sha(archive),files=len(files))))

def decode(name):
    name = name.removeprefix("TOP__").replace("__PVT__", "").replace("__DOT__", ".")
    name = name.replace("__BRA__", "[").replace("__KET__", "]")
    return re.sub(r"__0([0-9a-fA-F]{2})", lambda match: chr(int(match[1], 16)), name)


original_by_flat_name = collections.defaultdict(list)
with (WORK / "instances-all.csv").open() as stream:
    for row in csv.DictReader(stream):
        original_by_flat_name[row["instance"].replace("__", ".")].append(row["instance"])
called_original_scopes = set()


def owner_of_cpp_scope(raw_name):
    name = decode(raw_name)
    originals = original_by_flat_name[name.replace("__", ".")]
    assert len(originals) == 1, (raw_name, originals)
    original = originals[0]
    called_original_scopes.add(original)
    owners = [scope for scope in expected if original == scope or original.startswith(scope + ".")]
    assert owners, (raw_name, original)
    return max(owners, key=len)


tasks = {}
schedules = {}
caller_schedule_calls = 0
for path in sorted(OBJ.glob("Vsim___024root__*.cpp")):
    source = path.read_text()
    caller_schedule_calls += len(re.findall(
        r"^    Vsim___024root____Vthread__nba__s0__t7\(vlSelf, vlSymsp->__Vm_even_cycle__nba\);$", source, re.M))
    for match in re.finditer(r"void Vsim___024root__nba_mtask(\d+)\(void\* vlVoidSelf\) \{(.*?)\n\}", source, re.S):
        task = int(match[1])
        assert task not in tasks, task
        tasks[task] = {owner_of_cpp_scope(scope) for scope in re.findall(
            r"\(\(&vlSymsp->vlInst\.(TOP__[A-Za-z_0-9]+)\)\)", match[2])}
        if re.search(r"Vsim___024root___nba_[A-Za-z_0-9]+\(vlSelf\)", match[2]):
            tasks[task].add("caliptra_top_tb")
        if re.search(r"// Inlined CFunc: _nba_[A-Za-z_0-9]*__TOP__\d+$", match[2], re.M):
            tasks[task].add("caliptra_top_tb")
        root_fields = set(re.findall(r"vlSelfRef\.([A-Za-z_0-9]+)", match[2])) - {"__VnbaTriggered"}
        if root_fields:
            # Unretained testbench logic may be inlined directly into an mtask.
            # Include these operations, not only calls to standalone functions.
            assert all(re.match(r"(?:__Vdly(?:_Mask)?__)?caliptra_top_tb__DOT__", name) for name in root_fields), root_fields
            tasks[task].add("caliptra_top_tb")
    for match in re.finditer(r"void Vsim___024root____Vthread__nba__s(\d+)__t(\d+)"
                            r"\(void\* voidSelf, bool even_cycle\) \{(.*?)\n\}", source, re.S):
        assert int(match[1]) == 0
        worker = (int(match[2]) + 1) % 8
        assert worker not in schedules, worker
        schedules[worker] = {"tasks": list(map(int, re.findall(r"^    Vsim___024root__nba_mtask(\d+)\(", match[3], re.M))),
                             "waits": match[3].count(".waitUntilUpstreamDone("),
                             "signals": match[3].count(".signalUpstreamDone(")}
assert set(schedules) == set(range(8)), schedules
assert caller_schedule_calls == 1, caller_schedule_calls
owners = collections.defaultdict(set)
scheduled = set()
for worker, row in schedules.items():
    for task in row["tasks"]:
        assert task not in scheduled, task
        scheduled.add(task)
        for scope in tasks[task]:
            owners[scope].add(worker)
assert scheduled == set(tasks)
assert all(tasks.values()), "An NBA task has logic without an audited scope owner"
for scope, (_, _, worker) in expected.items():
    if scope == "caliptra_top_tb":
        pass
    elif scope == "caliptra_top_tb.__rtlmeter_utils_u":
        assert owners[scope] <= {0}, (scope, owners[scope])
    else:
        assert owners[scope] == {worker}, (scope, owners[scope], worker)

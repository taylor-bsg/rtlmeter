"""Pinned inputs and LLVM-only environment for Caliptra placement experiments."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT=Path(__file__).resolve().parent
WORK=ROOT.parent
INTEGRATION=WORK/'thread-unit-profile-followup'
COMPILER=INTEGRATION/'compiler'
REPO=WORK/'rtlmeter-unit-profiles'
REMOTE='/home/mbt-minion/kk-worker/caliptra-placement-20261027'
TESTS=('hmac','mlkem','sha3','trng')

def read(path):return json.loads(path.read_text())
def save(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,indent=2)+'\n')
def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def environment():
    env=dict(os.environ)
    for name in ('VERILATOR_ROOT','VERILATOR_BIN','MAKEFLAGS','CFLAGS','CXXFLAGS','CPPFLAGS',
                 'LDFLAGS','LD_PRELOAD','LD_LIBRARY_PATH','OBJCACHE'):
        env.pop(name,None)
    env.update(CC='/usr/bin/clang-21',CXX='/usr/bin/clang++-21',LINK='/usr/bin/clang++-21',
               VERILATOR_ROOT=str(COMPILER),VERILATOR_BIN=str(COMPILER/'bin/verilator_bin'),
               CCACHE_DISABLE='1',PATH='/usr/local/bin:/usr/bin:/bin')
    return env

def validate_sources():
    assert subprocess.check_output(['git','status','--porcelain'],cwd=COMPILER)==b''
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=COMPILER,text=True).strip()=='2487df5b4b8665f0caf8aed7ea174d13c037bf19'
    assert digest(COMPILER/'bin/verilator_bin')==read(INTEGRATION/'binaries.json')['verilator_bin']
    record=read(INTEGRATION/'inventory/Caliptra/input.json')
    assert digest(REPO/'designs/Caliptra/descriptor.yaml')==record['descriptor_sha256']
    for path,sha in record['source_sha256'].items():assert digest(REPO/path)==sha,path
    staged={};filelist=[]
    for category in ('verilogSourceFiles','verilogIncludeFiles','cppSourceFiles','cppIncludeFiles'):
        paths=[REPO/'designs/Caliptra'/name for part in record['compile'] for name in part.get(category,[])]
        if category=='verilogSourceFiles':paths.append(REPO/'rtl/__rtlmeter_utils.sv')
        for path in paths:
            name=category+'/'+path.name
            assert digest(Path(record['cwd'])/name)==digest(path),name
            staged[name]=digest(path)
            if category in ('verilogSourceFiles','cppSourceFiles'):filelist.append(name)
    assert (Path(record['cwd'])/'filelist').read_text().splitlines()==filelist
    staged['filelist']=digest(Path(record['cwd'])/'filelist')
    save(ROOT/'staged-source-audit.json',dict(passed=True,sha256=staged))
    save(ROOT/'input.json',record)
    save(ROOT/'source-provenance.json',dict(
        compiler_commit='2487df5b4b8665f0caf8aed7ea174d13c037bf19',
        compiler_sha256=digest(COMPILER/'bin/verilator_bin'),
        rtlmeter_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),
        unchanged_scheduler_and_merging=True,compiler_integration=read(INTEGRATION/'source-provenance.json')))
    return record

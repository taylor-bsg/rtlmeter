"""Use sampled call chains to assign library work and distinguish ACT from NBA."""
import collections
import re
from common import ROOT, TESTS, read, save

ownership=read(ROOT/'static-function-ownership.json')['function_units']
reports={}
for test in TESTS:
    run=ROOT/'remote-evidence/results/callgraph'/('Caliptra-default-'+test)/'Caliptra-default-static-8/round-1'
    if not (run/'samples.txt').exists():continue
    tids={int(t):cpus[0] for s in read(run/'placement.json')['samples'] for t,cpus in s['affinities'].items()}
    totals=collections.Counter();categories=collections.defaultdict(collections.Counter)
    unit_cycles=collections.Counter();ambiguity=collections.Counter();memory_parents=collections.defaultdict(collections.Counter)
    samples=0;missing=0
    for block in (run/'samples.txt').read_text().split('\n\n'):
        lines=block.splitlines()
        if not lines:continue
        m=re.fullmatch(r'\s*(\d+)/(\d+)\s+(\d+)\s*',lines[0]);assert m,lines[:2]
        worker=tids[int(m[2])];period=int(m[3]);samples+=1;totals[worker]+=period
        frames=[]
        for line in lines[1:]:
            match=re.fullmatch(r'\s*([0-9a-f]+) (.+) \(([^()]*)\)',line);assert match,line
            frames.append(match[2])
        if not frames:categories[worker]['unresolved']+=period;missing+=1;continue
        leaf=frames[0];names=[f.split('(')[0] for f in frames]
        nba=any('Vthread__nba' in f or 'nba_mtask' in f or 'runExecGraph_nba' in f for f in names)
        act=any(f.startswith('Vsim___024root___eval_') and '__act' in f for f in names)
        unit=None
        if 'VlMTaskVertex::waitUntilUpstreamDone' in leaf:category='dependency_wait'
        elif 'VlWorkerThread::dequeWork' in leaf:category='dispatch_wait'
        elif 'VlMTaskVertex::signalUpstreamDone' in leaf:category='dependency_signal'
        elif 'sched_yield' in leaf:category='yield'
        elif 'Vthread__nba' in leaf or 'runExecGraph_nba' in leaf:category='scheduler_other'
        elif nba:
            candidates=next((ownership[f][str(worker)] for f in names if f in ownership and str(worker) in ownership[f]),[])
            category='nba_unit_work' if candidates else 'nba_unresolved'
            if len(candidates)==1:unit=candidates[0];unit_cycles[unit]+=period
            elif candidates:ambiguity[' | '.join(candidates)]+=period
        elif act and worker==0:category='serial_act'
        elif worker==0:category='serial_other'
        else:category='unresolved'
        categories[worker][category]+=period
        if 'memmove' in leaf or 'memcpy' in leaf or 'memset' in leaf:
            parent=next((f for f in names[1:] if f.startswith('Vsim_')), '[unresolved]')
            memory_parents[worker][category+' | '+(unit or parent)]+=period
    reports[test]=dict(diagnostic_only=True,samples=samples,missing_stacks=missing,
        binary_sha256=read(run/'summary.json')['binary_sha256'],
        profiled_elapsed=read(run/'summary.json')['seconds'],unit_cycles=unit_cycles,ambiguous_cycles=ambiguity,
        workers=[dict(worker=w,cycles=totals[w],categories=categories[w],
                      percentages={k:100*v/totals[w] for k,v in categories[w].items()}) for w in range(8)],
        memory_copy_callers={str(w):dict(c.most_common()) for w,c in memory_parents.items()},
        caveats=['Cycle-sampled call stacks at 199 Hz; aggregate work estimates, not exact task durations.',
                 'Library time is assigned through observed generated-code callers on the sampled worker.',
                 'Caller ACT and NBA are distinguished by stack ancestry, including reused helper functions.',
                 'Unknown and ambiguous work remains separate; no instruction or memory-copy count is inferred.'])
    print(test,'samples',samples,'missing',missing)
    for w in reports[test]['workers']:print(w['worker'],{k:round(v,1) for k,v in w['percentages'].items()})
    total=sum(unit_cycles.values())
    print('Units',[(name,round(100*v/total,1)) for name,v in unit_cycles.most_common(8)])
save(ROOT/'static-callgraph-profile.json',reports)

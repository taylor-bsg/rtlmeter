"""Estimate per-unit NBA costs from sampled functions and audited task ownership."""
import collections
import csv
import functools
import re
import sys
from common import ROOT, INTEGRATION, TESTS, read, save

kind=sys.argv[1] if len(sys.argv)>1 else 'static'
label=f'Caliptra-default-{kind}-8';obj=ROOT/'models'/label/'obj_dir'
audit=read(ROOT/(kind+'-assignment-audit.json'));assert audit['passed']
bodies={}
for path in obj.glob('*.cpp'):
    source=path.read_text()
    for m in re.finditer(r'^(?:VL_INLINE_OPT )?[^\n;{}]+? (Vsim_\w+)\([^;{}]*\) \{\n(.*?)^\}',source,re.M|re.S):
        assert m[1] not in bodies,m[1]
        bodies[m[1]]=m[2]
calls={f:set(re.findall(r'\b(Vsim_\w+)\(',body)) for f,body in bodies.items()}
@functools.lru_cache(None)
def reachable(f):return {f}|set().union(*(reachable(g) for g in calls.get(f,()) if g!=f))
task_workers={str(t):int(w) for w,row in audit['schedules'].items() for t in row['tasks']}
function_units=collections.defaultdict(lambda:collections.defaultdict(set))
originals={}
with (INTEGRATION/'inventory/Caliptra/instances-all.csv').open() as stream:
    for row in csv.DictReader(stream):originals[row['instance'].replace('__','.')]=row['instance']
def scope_owner(raw):
    name=raw.removeprefix('TOP__').replace('__PVT__','').replace('__DOT__','.').replace('__BRA__','[').replace('__KET__',']')
    name=re.sub(r'__0([0-9a-fA-F]{2})',lambda m:chr(int(m[1],16)),name)
    original=originals[name.replace('__','.')]
    return max((s for s in audit['owners'] if original==s or original.startswith(s+'.')),key=len)
for task,units in audit['tasks'].items():
    worker=task_workers[task];name='Vsim___024root__nba_mtask'+task
    function_units[name][worker].update(units)
    for f,scope in re.findall(r'(Vsim_\w+)\(\(&vlSymsp->vlInst\.(TOP__\w+)\)\)',bodies[name]):
        owner=scope_owner(scope)
        for g in reachable(f):function_units[g][worker].add(owner)
    for f in re.findall(r'(Vsim___024root___nba_\w+)\(vlSelf\)',bodies[name]):
        for g in reachable(f):function_units[g][worker].add('caliptra_top_tb')
# Functions reachable from serial ACT must not be reassigned based on their source module.
serial_reachable=set()
for f in bodies:
    if f.startswith('Vsim___024root___eval_act') or f.startswith('Vsim___024root___eval_triggers__act'):
        serial_reachable.update(reachable(f))
save(ROOT/(kind+'-function-ownership.json'),dict(
    function_units={f:{str(w):sorted(units) for w,units in ws.items()} for f,ws in function_units.items()},
    serial_reachable=sorted(serial_reachable),task_workers=task_workers,tasks=audit['tasks']))
reports={}
for test in TESTS:
    run=ROOT/'remote-evidence/results/samples'/('Caliptra-default-'+test)/label/'round-1'
    if not (run/'summary.json').exists():continue
    tids={}
    for sample in read(run/'placement.json')['samples']:
        for tid,cpus in sample['affinities'].items():
            assert len(cpus)==1 and tids.get(int(tid),cpus[0])==cpus[0];tids[int(tid)]=cpus[0]
    assert sorted(tids.values())==list(range(8))
    instructions={};functions={};current=None
    for line in (run/'disassembly.txt').read_text().splitlines():
        m=re.match(r'^[0-9a-f]+ <(.*)>:$',line)
        if m:current=m[1]
        m=re.match(r'^\s*([0-9a-f]+):\s+(.*)$',line)
        if m:instructions[int(m[1],16)]=m[2].strip();functions[int(m[1],16)]=current
    # Find short pause loops and their conditional back edges without quadratic scanning.
    addresses=sorted(instructions);positions={ip:i for i,ip in enumerate(addresses)};wait_ips=set()
    for ip,insn in instructions.items():
        if insn!='pause':continue
        j=positions[ip];near=addresses[max(0,j-40):j+50]
        for end in near:
            m=re.match(r'j\w+\s+([0-9a-f]+)\s',instructions[end])
            if not m:continue
            begin=int(m[1],16)
            if begin<=ip<=end and end-begin<=160 and functions[end]==functions[ip]:
                block=[a for a in near if begin<=a<=end]
                if all(not instructions[a].startswith('call') or 'sched_yield' in instructions[a] for a in block):wait_ips.update(block)
    totals=collections.Counter();categories=collections.defaultdict(collections.Counter)
    unit_cycles=collections.Counter();ambiguity=collections.Counter();symbols=collections.defaultdict(collections.Counter)
    samples=0
    with (run/'samples.txt').open() as stream:
        for line in stream:
            m=re.fullmatch(r'\s*(\d+)/(\d+)\s+(\d+)\s+([0-9a-f]+)\s+(.*?)\s+\((.*)\)\n?',line)
            assert m,line
            worker=tids[int(m[2])];period=int(m[3]);ip=int(m[4],16);symbol=m[5];f=symbol.split('(')[0]
            samples+=1;totals[worker]+=period;symbols[worker][symbol]+=period
            owners=function_units.get(f,{}).get(worker,set())
            if 'VlMTaskVertex::waitUntilUpstreamDone' in symbol or ip in wait_ips:
                cat='dependency_wait' if ('Vthread__nba' in symbol or 'MTask' in symbol) else 'dispatch_wait'
            elif 'sched_yield' in symbol:cat='yield'
            elif 'VlMTaskVertex::signalUpstreamDone' in symbol:cat='dependency_signal'
            elif 'Vthread__nba' in symbol or 'runExecGraph_nba' in symbol:cat='scheduler_other'
            elif worker==0 and f in serial_reachable and owners:cat='serial_or_caller_nba'
            elif worker==0 and f in serial_reachable:cat='serial_act'
            elif owners:
                cat='nba_unit_work'
                if len(owners)==1:unit_cycles[next(iter(owners))]+=period
                else:ambiguity[' | '.join(sorted(owners))]+=period
            elif worker==0 and f.startswith('Vsim'):cat='serial_other_generated'
            elif f.startswith('Vsim'):cat='other_generated'
            else:cat='runtime_library_other'
            categories[worker][cat]+=period
    elapsed=read(run/'summary.json')['seconds']
    reports[test]=dict(diagnostic_only=True,samples=samples,profiled_elapsed=elapsed,
        binary_sha256=read(run/'summary.json')['binary_sha256'],unit_cycles=unit_cycles,ambiguous_cycles=ambiguity,
        workers=[dict(worker=w,cycles=totals[w],categories=categories[w],
            percentages={k:100*v/totals[w] for k,v in categories[w].items()},
            top_symbols=symbols[w].most_common(12)) for w in range(8)],
        caveats=['Statistical cycle samples, including instruction skid; not exact task timings.',
                 'Only functions reachable from NBA tasks on the sampled worker are assigned to units.',
                 'Serial ACT, ambiguous shared functions, and library work are kept separate.',
                 'Sampling attaches after process launch; earliest initialization is not covered.'])
    print(test,'samples',samples,'ambiguous NBA fraction',sum(ambiguity.values())/max(1,sum(unit_cycles.values())+sum(ambiguity.values())))
    for w in reports[test]['workers']:print(w['worker'],{k:round(v,1) for k,v in w['percentages'].items()})
save(ROOT/(kind+'-runtime-profile.json'),reports)

"""Write the result narrative and update profile coverage after the evidence audit."""
from common import ROOT, REPO, TESTS, read

summary=read(ROOT/'summary.json');assert summary['passed'];selected=summary['selected']
target=REPO/'designs/Caliptra/verilator/results/2026-10-27'
table=(ROOT/'result-table.md').read_text();profiles=read(ROOT/'static-callgraph-profile.json')
rows=summary['configurations'];by={(r['case'],r['label']):r for r in rows}
comparisons=[]
for test in TESTS:
    case='Caliptra-default-'+test;mapped=by[case,selected]['median_seconds'];default=by[case,'Caliptra-default-default-8']['median_seconds']
    auto=by[case,'Caliptra-default-auto-8']['median_seconds'];serial=by[case,'Caliptra-default-serial-1']['median_seconds']
    comparisons.append((test,100*(1-mapped/default),100*(1-mapped/auto),100*(mapped/serial-1)))
all_faster=all(x[3]<0 for x in comparisons)
all_slower=all(x[3]>0 for x in comparisons)
outcome=('The mapped profile beats the serial reference on all four measured workloads.' if all_faster else
         'One worker is fastest on all four measured workloads. Automatic grouping is the fastest eight-worker configuration; the explicit map remains an experimental placement baseline.' if all_slower else
         'The mapped profile has mixed results against the serial reference. The validated profiles remain experimental; use the per-workload comparison below.')
comparison_table='| Workload | Reduction vs. default 8 | Reduction vs. automatic grouping | Change vs. serial |\n|---|---:|---:|---:|\n'
for test,default,auto,serial in comparisons:comparison_table+=f'| {test} | {default:.1f}% | {auto:.1f}% | {serial:+.1f}% |\n'
profile_table='| Workload | Caller cycles in serial ACT | Call-stack samples |\n|---|---:|---:|\n'
for test in TESTS:
    p=profiles[test];profile_table+=f'| {test} | {p["workers"][0]["percentages"]["serial_act"]:.1f}% | {p["samples"]:,} |\n'
mapping='''| Worker | Assigned units |
|---:|---|
| 0 | AXI testbench memory, device wrapper remainder, RTLmeter utility |
| 1 | ABR testbench memory |
| 2 | Key vault, DOE controller |
| 3 | PCR vault, SoC interface, testbench services remainder |
| 4 | Both masked PWM units |
| 5 | VeeR CPU, CSRNG, data vault, entropy source |
| 6 | AES, ECC, HMAC, SHA3, SHA256 |
| 7 | ABR remainder, both masked GS butterflies, SHA512 |
'''
text=f'''# Caliptra default: measured thread-unit placement

{outcome}

{table}
Times are medians of **two** isolated timing rounds per workload/configuration.
The final column compares the mapped eight-worker model with one worker.
Each workload retains its RTLmeter setting of `+iterations=1`. Round two reverses
both workload and configuration order. Timings include initialization,
simulation, and cleanup; profiling runs are excluded from this table.
The serial model has no grouping directives. The default eight-worker control
has no grouping directives. Automatic grouping and the mapped model select
the same 24 instances from 22 module types.

{comparison_table}
Positive reductions mean less elapsed time; a positive change versus serial means
a slowdown. Individual samples and ranges are in [summary.json](summary.json)
and [timings.csv](timings.csv). Two repetitions establish a short comparison,
not a claim of precise sub-percent differences.

## Placement and profiling

The initial map used the existing [0.25% hierarchy inventory](../../analysis/README.md),
disjoint NBA instruction-cost estimates, and shared-variable connectivity.
ABR's large arithmetic children are separate units. The initial static map
was slower than the serial model on all four correctness runs; it is retained
as [initial-static.vlt](initial-static.vlt).

Call-stack profiles distinguish serial ACT evaluation from NBA work, even when
both phases reuse a generated helper. They also attribute library copies through
their observed callers. The static map's profiles show the main limitation:

{profile_table}
These are fractions of sampled caller **cycles**, not exact wall-clock phase
timings or a serial fraction of the separate one-worker build. Most pool-worker
cycles were waiting for dispatch or dependencies. The first flat HMAC sample
gave different unit proportions from the call-stack profile; the solver uses
the four call-stack profiles, which consistently identify the AXI testbench
memory, key vault, and ABR memory among the largest NBA units. Flat profiles are
preserved as diagnostics, not used as complete work estimates.

Within the sampled serial ACT work, testbench services account for about 26.5%,
the masked GS butterflies for 17–18%, and masked PWM units for about 12%.
Those modules' ACT portions still execute on the caller even when their NBA
pieces are assigned elsewhere. The [serial ACT breakdown](serial-act-breakdown.json)
records module-type shares and the hottest generated functions.

The revised map puts AXI memory on the caller and keeps ABR memory and the key
vault on the caller's chiplet. Under those locality constraints, CP-SAT first
minimizes the largest normalized worker load across the four workloads, then
allows 3% slack while reducing chiplet imbalance and structural cuts. The solved
NBA chiplet totals differ by at most 2.9%. This is a model of sampled NBA work;
it covers attributed selected-unit work and excludes residual automatically
scheduled top-level tasks and ambiguous samples. It does not balance the serial
ACT phase or prove an optimal runtime placement.
The 59 shared-variable hyperedges count distinct variables, without width or
activity weighting, so their cut objective is a connectivity proxy, not bandwidth.

{mapping}
Worker `i` is pinned to physical CPU `i`. CPUs 0–3 and 4–7 are two four-core
chiplets on socket 0 of kk10 (dual AMD EPYC 9374F). Memory is bound to NUMA node 0.
The profile itself does not set affinity. The residual top-level testbench tasks
remain automatically scheduled; selected child units override their parents.
All 24 selected instances appear in the index listing. Every unit with emitted
NBA work has its owner verified in generated C++ dispatch, including descendant
interface calls; the RTLmeter utility has no emitted NBA task.
The portable profile produces byte-identical code to
the tested automatic control across all 293 generated C++/header/make files.

## Correctness and the startup-banner gate

The initial exact-output gate stopped on automatic grouping. Investigation found
only a permutation of two complete time-zero banners: memory preloading and
strap initialization print from separate `initial` blocks. No timing or profiling
phase was started by that failed gate. Its raw stop record is retained.

The reviewed comparator allows exactly those two unchanged banner blocks to
exchange order. Every other output byte, the clock count, and the RTLmeter post-hook
remain checked. Negative controls reject changed banner content and changed
subsequent output. Firmware console logs match the immutable package-60 evidence;
the emitted memory snapshots match the freshly checked serial run. These snapshots
are the testbench's emitted ranges, not a full-state equivalence proof.

The initial four configurations passed all 16 workload checks before profiling.
The revised mapping passed all four workload checks before timing. Every timed run
also passed the output, console, snapshot, affinity, and executable-page checks.
Each execution used a unique copied binary with resident executable pages on node 0.
Raw output hashes are retained even when the permitted banner ordering differs.

## Sources and tools

- RTLmeter input tree: `ce4d260ba7c61a92d194b30dbb4676258c700ed6`; Caliptra RTL,
  descriptor, utility, firmware and hook hashes are recorded and verified against
  the staged compilation/execution inputs. No RTL or firmware changes.
- Verilator: [`2487df5b4b8665f0caf8aed7ea174d13c037bf19`](https://github.com/taylor-bsg/verilator/tree/2487df5b4b8665f0caf8aed7ea174d13c037bf19),
  `codex/threads-unit-runtime-integration`. This combines worker assignment
  `8c052270`, final wide-zero-reset PR #8916 and final bit-copy PR #8933, with the
  documented test-comment compatibility adjustment. Scheduler, cost estimator,
  merging heuristics and runtime synchronization are unchanged between controls.
- Verilator and every fresh model use Clang 21.1.8. C++ compilation and linking
  explicitly use `/usr/bin/clang++-21`, with C++20 and the default hot-code `-Os`.
  Clang's default GCC 15 standard-library toolchain is permitted; no GCC compiler
  or GCC 11 C++ toolchain is selected. No PGO, LTO or custom unrolling flags.
- Flat diagnostics use `cycles:u` at 999 Hz; call stacks use `cycles:u` at 199 Hz
  with DWARF unwinding. Both attach shortly after launch and are excluded from
  the final timing samples. Statistical sampling and instruction skid apply.

## Files

- [Portable profile](../../threads-unit.vlt), [kk10 profile](../../threads-unit-kk10.vlt),
  and [index-to-instance listing](threads-unit-indices.txt).
- [Native audit](native-audit.json), [dispatch audit](runtime-assignment-audit.json),
  [runtime placement model](runtime-placement.json), and [call-stack analysis](static-callgraph-profile.json).
- [Interactive runtime profile](runtime-profile.html): download and open locally to
  compare worker work/wait distributions and attributed units across the four workloads.
- [Raw native evidence](native-evidence.tar.gz) and [reproduction scripts/provenance](reproduction.tar.gz).
  The archive retains code hashes, build/run logs, decoded perf samples, and
  correctness/affinity records. Native binaries and binary perf recordings remain on kk10.
  Archive manifests verify member hashes. Repeated disassemblies have only their
  objdump pathname header normalized and are stored as hard links; original header
  paths and hashes are recorded so the original derived text can be reconstructed.

Only Caliptra `default` with eight workers and the four listed performance workloads
is validated here. Other worker counts and the separate `hello` test remain untested
by this placement experiment. NVDLA placement is still pending.
'''
(target/'RESULTS.md').write_text(text)

doc=REPO/'docs/source/threads-unit.rst';source=doc.read_text()
start=source.index('Caliptra and NVDLA preparation\n')
end=source.index('Coverage and validation\n',start)
section='''Caliptra on kk10
----------------

``designs/Caliptra/verilator/threads-unit.vlt`` selects 24 instances from 22 module
types. ``threads-unit-kk10.vlt`` maps the same units onto eight workers. The large
ABR arithmetic children override their enclosing ABR unit. Worker 0 is the caller;
workers 0–3 and 4–7 occupy two chiplets on socket 0, with memory on node 0.
Residual top-level testbench tasks remain automatically scheduled.

The machine map puts AXI testbench memory on worker 0, ABR memory on worker 1,
and the key vault on worker 2. The remaining map uses runtime samples from HMAC,
MLKEM, SHA3 and TRNG. Every unit with emitted NBA work has its owner audited in
generated dispatch; the selected RTLmeter utility has no emitted NBA task.
The same four workloads pass the output, console, snapshot and placement checks.

'''+outcome+'''

.. list-table:: Caliptra default, median seconds from two timing rounds
   :header-rows: 1

   * - Workload
     - 1 worker
     - Default 8
     - Auto units 8
     - Mapped 8
     - Speedup vs. 1 worker
'''
for test in TESTS:
    labels=['Caliptra-default-serial-1','Caliptra-default-default-8','Caliptra-default-auto-8',selected]
    values=[by['Caliptra-default-'+test,label] for label in labels]
    section+='   * - '+test+'\n'+''.join(f'     - {r["median_seconds"]:.3f}\n' for r in values)+f'     - {values[-1]["speedup_vs_one_worker"]:.2f}x\n'
section+='''
These runs use Clang 21.1.8, the final runtime/loop-optimization integration
``2487df5b4b8665f0caf8aed7ea174d13c037bf19``, and one workload iteration.
Call-stack profiles of the initial map place about 83% of caller cycles in serial
ACT evaluation, limiting what NBA placement can improve. The reviewed output gate
permits only the exact exchange of two independent startup-banner blocks; all
remaining output, clocks, console logs and emitted memory snapshots are checked.

See the `full Caliptra results, mapping and raw evidence
<https://github.com/taylor-bsg/rtlmeter/blob/codex/threads-unit-profiles/designs/Caliptra/verilator/results/2026-10-27/RESULTS.md>`_
and the existing `0.25% hierarchy inventory
<https://github.com/taylor-bsg/rtlmeter/blob/codex/threads-unit-profiles/designs/Caliptra/verilator/analysis/README.md>`_.
Only the default design size with eight workers is mapped and measured.

NVDLA preparation
-----------------

The `NVDLA hierarchy inventory
<https://github.com/taylor-bsg/rtlmeter/blob/codex/threads-unit-profiles/designs/NVDLA/verilator/analysis/README.md>`_
contains 128 instances at or above the 0.25% static-work threshold, a topology
diagram, candidate unit boundaries and structural connection lists. Unit selection,
worker assignment and placement benchmarking remain pending.

'''
source=source[:start]+section+source[end:]
marker='.. list-table:: Designs still needing profiles and validation\n'
addition='''   * - Caliptra
     - ``threads-unit.vlt``
     - Automatic grouping of 24 units; code-identical to the LLVM control tested
       on HMAC, MLKEM, SHA3 and TRNG above.
   * - Caliptra
     - ``threads-unit-kk10.vlt``
     - Runtime-based eight-worker map with audited dispatch and all four workloads
       checked. See the comparison above; the profile remains experimental.

'''
assert marker in source;source=source.replace(marker,addition+marker)
source=source.replace('   * - Caliptra\n     - Hierarchy/connectivity analysis complete; unit selection and placement pending.\n','')
doc.write_text(source)
print('Wrote Caliptra results and updated profile coverage')

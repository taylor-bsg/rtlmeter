"""Generate fresh serial/default/unit controls and explicit worker candidates."""
from concurrent.futures import ThreadPoolExecutor
import re
import subprocess
import sys
import time
from common import ROOT, COMPILER, digest, environment, read, save, validate_sources

def generate(kind):
    record=read(ROOT/'input.json')
    workers=1 if kind=='serial' else 8
    label=f'Caliptra-default-{kind}-{workers}'
    dest=ROOT/'models'/label
    (dest/'obj_dir').mkdir(parents=True,exist_ok=False)
    args=record['args'].copy();args[args.index('--threads')+1]=str(workers)
    if kind not in ('serial','default'):
        args+=['--threads-unit-list',str(ROOT/'profiles'/(kind+'.vlt'))]
    if workers==8:args+=['--dumpi-V3ExecGraph','4','--debugi-V3OrderParallel','4']
    args+=['--Mdir',str(dest/'obj_dir'),'--no-skip-identical']
    command=[str(COMPILER/'bin/verilator'),*args]
    save(dest/'command.json',dict(command=command,cwd=record['cwd'],compiler_sha256=digest(COMPILER/'bin/verilator_bin')))
    start=time.monotonic();print('GENERATE',label,flush=True)
    with (dest/'output.log').open('w') as log:
        p=subprocess.run(command,cwd=record['cwd'],env=environment(),stdout=log,stderr=subprocess.STDOUT)
    result=dict(label=label,kind=kind,workers=workers,returncode=p.returncode,seconds=time.monotonic()-start)
    if p.returncode==0:
        result['files']={path.name:digest(path) for path in (dest/'obj_dir').iterdir() if path.suffix in ('.cpp','.h','.mk')}
        stats=(dest/'obj_dir/Vsim__stats.txt').read_text()
        result['stats']={key:int(m[1]) for key in ('mtask count','edge count','total graph cost','critical path cost')
                         if (m:=re.search(r'MTask graph, final, '+key+r'\s+(\d+)',stats))}
    save(dest/'generation.json',result)
    print('GENERATED',label,p.returncode,flush=True)
    assert p.returncode==0,dest
    return result

if __name__=='__main__':
    validate_sources()
    kinds=sys.argv[1:] or ['serial','default','auto']
    with ThreadPoolExecutor(max_workers=3) as pool:
        save(ROOT/('generation-'+','.join(kinds)+'.json'),list(pool.map(generate,kinds)))

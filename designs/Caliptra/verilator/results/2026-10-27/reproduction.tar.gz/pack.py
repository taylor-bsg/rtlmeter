"""Stage exact generated models, LLVM runtime, immutable firmware and references."""
import shutil
import tarfile
from common import ROOT, WORK, COMPILER, REPO, TESTS, digest, read, save, validate_sources

record=validate_sources();dest=ROOT/'payload';dest.mkdir(exist_ok=False)
def copy(source,target):
    target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
for kind in ('serial','default','auto','static'):
    label='Caliptra-default-'+kind+('-1' if kind=='serial' else '-8');model=ROOT/'models'/label
    assert read(model/'generation.json')['returncode']==0
    for path in (model/'obj_dir').iterdir():
        if path.suffix in ('.cpp','.h','.mk','.txt'):copy(path,dest/'models'/label/path.name)
    for part in record['compile']:
        assert not part.get('cppIncludeFiles')
        for name in part.get('cppSourceFiles',[]):copy(REPO/'designs/Caliptra'/name,dest/'models'/label/'cppSourceFiles'/Path(name).name)
    for name in ('generation.json','command.json'):copy(model/name,dest/'provenance'/label/name)
for path in (COMPILER/'include').rglob('*'):
    if path.is_file() and path.suffix not in ('.o','.d','.a','.gch','.pch','.pyc','.md'):
        copy(path,dest/'runtime/include'/path.relative_to(COMPILER/'include'))
for name in ('verilator_includer','verilator_ccache_report'):copy(COMPILER/'bin'/name,dest/'runtime/bin'/name)
for name in ('worker.py','affinity.c'):copy(WORK/'bit-copy-suite'/name,dest/name)
audits={}
for test in TESTS:
    case='Caliptra-default-'+test;old=WORK/'package60-review/payloads/native/workloads'/case
    expected=next(part['tests'][test] for part in record['execute'] if part and test in part.get('tests',{}))
    spec=read(old/'case.json');assert spec['args']==expected['args']==['+iterations=1']
    assert spec['files']==[name.rsplit('/',1)[1] for name in expected['files']]
    for name in expected['files']:assert digest(old/name.rsplit('/',1)[1])==digest(REPO/'designs/Caliptra'/name),name
    assert spec['post']=='post.bash' and digest(old/'post.bash')==digest(REPO/'designs/Caliptra/tests/post.bash')
    audits[case]={p.name:digest(p) for p in old.iterdir() if p.is_file()}
    shutil.copytree(old,dest/'workloads'/case)
    copy(WORK/'package60-review/remote-evidence/results/references'/(case+'.json'),dest/'results/references'/(case+'.json'))
save(ROOT/'workload-audit.json',dict(passed=True,workloads=audits))
for name in ('run_remote.py','source-provenance.json','input.json','staged-source-audit.json','workload-audit.json','static-placement.json'):
    copy(ROOT/name,dest/name)
shutil.copytree(ROOT/'profiles',dest/'profiles')
save(dest/'payload-manifest.json',{str(p.relative_to(dest)):digest(p) for p in dest.rglob('*') if p.is_file()})
with tarfile.open(ROOT/'payload.tar.gz','w:gz',compresslevel=3) as tar:
    for path in sorted(dest.iterdir()):tar.add(path,arcname=path.name)
print('Payload bytes:',(ROOT/'payload.tar.gz').stat().st_size)

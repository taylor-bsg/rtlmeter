"""Allow only the observed permutation of two independent time-zero banners."""
import hashlib
import json
from pathlib import Path

MEMORY=(b'Iterations: 1\nDCCM pre-load from 50000000 to 5003ffff\nDCCM pre-load completed\n'
        b'ICCM pre-load from 40000000 to 4003ffff\nICCM pre-load completed\n'
        b'MBOX pre-load from 00000000 to 00010000\nMBOX pre-load completed\nRandomized mode to mode_not_empty\n')
STRAPS=(b'STRAP_SS_KEY_RELEASE_KEY_SIZE set to default value 0x0040\n'
        b'STRAP_SS_KEY_RELEASE_BASE_ADDR set to default value 0x0000000123440000\n'+b'\n'*7)
ANCHOR=b'CLP: Waiting for cptra_rst_b deassertion\n'

def canonical(data):
    before,sep,after=data.partition(ANCHOR)
    assert sep==ANCHOR and before in (MEMORY+STRAPS,STRAPS+MEMORY),'Unexpected startup output'
    return MEMORY+STRAPS+ANCHOR+after

def compare(case,dest,result,reference):
    expected=json.loads(reference.read_text())
    baseline=(reference.parent/(case+'.stdout.log')).read_bytes()
    actual=(dest/'_execute/stdout.log').read_bytes()
    assert hashlib.sha256(baseline).hexdigest()==expected['output_sha256'],'Reference log hash mismatch'
    assert hashlib.sha256(actual).hexdigest()==result['output_sha256'],'Actual log hash mismatch'
    assert {k:v for k,v in expected.items() if k!='output_sha256'}=={k:v for k,v in result.items() if k!='output_sha256'},'Cycle/check mismatch; do not benchmark'
    assert canonical(actual)==canonical(baseline),'Functional output mismatch; do not benchmark'
    report=dict(passed=True,raw_output_identical=actual==baseline,
                canonical_output_sha256=hashlib.sha256(canonical(actual)).hexdigest(),
                adjustment='Only the two complete time-zero banner blocks may exchange order; their contents and all subsequent bytes are exact')
    (dest/'output-comparison.json').write_text(json.dumps(report,indent=2)+'\n')
    return True

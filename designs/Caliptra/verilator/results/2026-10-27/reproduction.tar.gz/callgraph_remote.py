"""Distinguish serial ACT from NBA and attribute memcpy using DWARF call stacks."""
import fcntl
import os
from pathlib import Path
import subprocess
import worker_checked as worker
import side_outputs

CASES=['Caliptra-default-'+t for t in ('hmac','mlkem','sha3','trng')]
LABEL='Caliptra-default-static-8'
def sample(case):
    real_popen=subprocess.Popen;recorders=[];logs=[]
    def launch(command,*args,**kwargs):
        p=real_popen(command,*args,**kwargs)
        if isinstance(command,list) and '+verilator+quiet' in command:
            dest=Path(kwargs['cwd']);log=(dest/'perf.log').open('w');logs.append(log)
            rec=real_popen(['perf','record','-q','-e','cycles:u','-F','199','--call-graph','dwarf,8192',
                           '-p',str(p.pid),'-o',str(dest/'samples.data')],env=worker.env(),stdout=log,stderr=subprocess.STDOUT)
            recorders.append((rec,dest))
        return p
    subprocess.Popen=launch
    try:row=worker.execute(case,LABEL,'callgraph',1)
    finally:subprocess.Popen=real_popen
    assert len(recorders)==1
    for rec,dest in recorders:
        assert rec.wait(timeout=30)==0
        with (dest/'samples.txt').open('w') as stream:
            subprocess.run(['perf','script','-i',str(dest/'samples.data'),'-F','pid,tid,period,ip,sym,dso'],
                           env=worker.env(),stdout=stream,check=True)
        side_outputs.check(case,dest)
    for log in logs:log.close()
    print('CALLGRAPH',case,'DONE',flush=True)
    return row

if __name__=='__main__':
    os.sched_setaffinity(0,{63})
    with worker.LOCK.open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        try:
            assert not (worker.ROOT/'results/STOP.json').exists()
            assert worker.read(worker.ROOT/'results/profiling-DONE.json')['passed']
            for name,sha in worker.read(worker.ROOT/'callgraph-manifest.json').items():assert worker.digest(worker.ROOT/name)==sha,name
            rows=[sample(case) for case in CASES]
            worker.save(worker.ROOT/'results/callgraphs-DONE.json',dict(passed=True,runs=rows))
        except BaseException as error:
            worker.save(worker.ROOT/'results/STOP.json',dict(error=repr(error)));raise

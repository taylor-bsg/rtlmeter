"""Stage one fresh placement candidate without changing prior models or evidence."""
import shutil
import sys
import tarfile
from common import ROOT, digest, read, save, validate_sources

kind=sys.argv[1];validate_sources();label=f'Caliptra-default-{kind}-8'
model=ROOT/'models'/label;dest=ROOT/(kind+'-payload');dest.mkdir(exist_ok=False)
assert read(model/'generation.json')['returncode']==0
assert read(ROOT/(kind+'-assignment-audit.json'))['passed']
def copy(source,target):target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
for path in (model/'obj_dir').iterdir():
    if path.suffix in ('.cpp','.h','.mk','.txt'):copy(path,dest/'models'/label/path.name)
for name in ('generation.json','command.json'):copy(model/name,dest/'provenance'/label/name)
for name in ('follow_remote.py','side_outputs.py','collect.py',kind+'-assignment-audit.json',kind+'-placement.json'):
    copy(ROOT/name,dest/name)
copy(ROOT/'profiles'/(kind+'.vlt'),dest/'profiles'/(kind+'.vlt'))
save(dest/(kind+'-manifest.json'),{str(p.relative_to(dest)):digest(p) for p in dest.rglob('*') if p.is_file()})
with tarfile.open(ROOT/(kind+'-payload.tar.gz'),'w:gz',compresslevel=3) as tar:
    for p in dest.iterdir():tar.add(p,arcname=p.name)
print('Candidate bytes:',(ROOT/(kind+'-payload.tar.gz')).stat().st_size)

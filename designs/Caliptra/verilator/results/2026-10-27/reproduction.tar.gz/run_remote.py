"""Build all controls, gate correctness, then collect independent runtime profiles."""
from concurrent.futures import ThreadPoolExecutor
import fcntl
import os
from pathlib import Path
import subprocess
import worker

LABELS=['Caliptra-default-'+kind+('-1' if kind=='serial' else '-8') for kind in ('serial','default','auto','static')]
CASES=['Caliptra-default-'+test for test in ('hmac','mlkem','sha3','trng')]

def sample(case,label):
    real_popen=subprocess.Popen;recorders=[];logs=[]
    def launch(command,*args,**kwargs):
        process=real_popen(command,*args,**kwargs)
        if isinstance(command,list) and '+verilator+quiet' in command:
            dest=Path(kwargs['cwd']);log=(dest/'perf.log').open('w');logs.append(log)
            recorder=real_popen(['perf','record','-q','-e','cycles:u','-F','999','-p',str(process.pid),'-o',str(dest/'samples.data')],
                                env=worker.env(),stdout=log,stderr=subprocess.STDOUT)
            recorders.append((recorder,dest))
        return process
    subprocess.Popen=launch
    try:row=worker.execute(case,label,'samples',1)
    finally:subprocess.Popen=real_popen
    assert len(recorders)==1
    for recorder,dest in recorders:
        assert recorder.wait(timeout=30)==0
        for name,command in [
            ('samples.txt',['perf','script','-i',str(dest/'samples.data'),'-F','pid,tid,period,ip,sym,dso']),
            ('symbols.txt',['nm','-S','--defined-only',str(dest/'Vsim')]),
            ('disassembly.txt',['objdump','-d','-C','--no-show-raw-insn',str(dest/'Vsim')])]:
            with (dest/name).open('w') as stream:subprocess.run(command,stdout=stream,check=True,env=worker.env())
    for log in logs:log.close()
    print('PROFILED',case,label,flush=True)
    return row

if __name__=='__main__':
    os.sched_setaffinity(0,{63})
    with worker.LOCK.open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        try:
            assert 'clang version 21.1.8' in subprocess.check_output(['/usr/bin/clang++-21','--version'],text=True)
            for name,sha in worker.read(worker.ROOT/'payload-manifest.json').items():assert worker.digest(worker.ROOT/name)==sha,name
            subprocess.run(['/usr/bin/clang-21','-O2','-shared','-fPIC','-o',str(worker.ROOT/'affinity.so'),
                            str(worker.ROOT/'affinity.c'),'-ldl','-pthread'],env=worker.env(),check=True)
            with ThreadPoolExecutor(max_workers=4) as pool:list(pool.map(worker.build,[(label,i) for i,label in enumerate(LABELS)]))
            for case in CASES:
                for label in LABELS:worker.execute(case,label,'check',0)
            worker.save(worker.ROOT/'results/correctness-DONE.json',dict(passed=True,executions=16))
            profiles=[sample(case,'Caliptra-default-static-8') for case in CASES]
            worker.save(worker.ROOT/'results/profiling-DONE.json',dict(passed=True,profiles=profiles))
        except BaseException as error:
            worker.save(worker.ROOT/'results/STOP.json',dict(error=repr(error)))
            raise
